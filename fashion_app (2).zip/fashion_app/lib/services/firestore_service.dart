import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import '../models/product.dart';
import '../models/cart_item.dart';
import '../data/mock_products.dart';

class FirestoreService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  // Helper to map DocumentSnapshot to Product model
  Product _mapDocToProduct(DocumentSnapshot doc) {
    if (!doc.exists) {
      return getProductById(doc.id);
    }
    final data = doc.data() as Map<String, dynamic>;
    final List<dynamic> colorValues = data['colors'] ?? [];
    final List<Color> colors = colorValues.map((val) => Color(val as int)).toList();
    
    return Product(
      id: data['id'] ?? doc.id,
      brand: data['brand'] ?? '',
      name: data['name'] ?? '',
      price: (data['price'] as num?)?.toDouble() ?? 0.0,
      imageUrl: data['imageUrl'] ?? '',
      rating: (data['rating'] as num?)?.toDouble() ?? 0.0,
      reviewCount: (data['reviewCount'] as num?)?.toInt() ?? 0,
      description: data['description'] ?? '',
      colors: colors,
      sizes: List<String>.from(data['sizes'] ?? []),
      lookIds: List<String>.from(data['lookIds'] ?? []),
    );
  }

  // Stream of all products from Firestore
  Stream<List<Product>> getProductsStream() {
    return _db.collection('products').snapshots().map((snapshot) {
      return snapshot.docs.map((doc) => _mapDocToProduct(doc)).toList();
    });
  }

  // Stream of multiple products by their IDs
  Stream<List<Product>> getProductsByIdsStream(List<String> ids) {
    if (ids.isEmpty) {
      return Stream.value([]);
    }
    return _db
        .collection('products')
        .where(FieldPath.documentId, whereIn: ids)
        .snapshots()
        .map((snapshot) {
          return snapshot.docs.map((doc) => _mapDocToProduct(doc)).toList();
        });
  }

  // Stream of cart items for a specific user
  Stream<List<CartItem>> getCartStream(String userId) {
    return _db
        .collection('users')
        .doc(userId)
        .collection('cart')
        .orderBy('timestamp', descending: false)
        .snapshots()
        .asyncMap((snapshot) async {
          final cartItems = <CartItem>[];
          for (final doc in snapshot.docs) {
            final data = doc.data();
            final productId = data['productId'] as String;
            final productDoc = await _db.collection('products').doc(productId).get();
            final product = _mapDocToProduct(productDoc);
            cartItems.add(CartItem(
              product: product,
              selectedColor: Color(data['selectedColor'] as int),
              selectedSize: data['selectedSize'] as String,
              quantity: data['quantity'] as int,
            ));
          }
          return cartItems;
        });
  }

  // Add item to cart
  Future<void> addToCart(String userId, Product product, Color color, String size, {int quantity = 1}) async {
    final cartRef = _db.collection('users').doc(userId).collection('cart');
    final itemId = '${product.id}_${color.value}_$size';
    final doc = await cartRef.doc(itemId).get();
    
    if (doc.exists) {
      final currentQty = doc.data()?['quantity'] ?? 0;
      await cartRef.doc(itemId).update({'quantity': currentQty + quantity});
    } else {
      await cartRef.doc(itemId).set({
        'id': itemId,
        'productId': product.id,
        'selectedColor': color.value,
        'selectedSize': size,
        'quantity': quantity,
        'timestamp': FieldValue.serverTimestamp(),
      });
    }
  }

  // Update cart item quantity
  Future<void> updateCartQuantity(String userId, String productId, Color color, String size, int newQty) async {
    final itemId = '${productId}_${color.value}_$size';
    final docRef = _db.collection('users').doc(userId).collection('cart').doc(itemId);
    if (newQty <= 0) {
      await docRef.delete();
    } else {
      await docRef.update({'quantity': newQty});
    }
  }

  // Remove item from cart
  Future<void> removeFromCart(String userId, String productId, Color color, String size) async {
    final itemId = '${productId}_${color.value}_$size';
    await _db.collection('users').doc(userId).collection('cart').doc(itemId).delete();
  }

  // Clear cart
  Future<void> clearCart(String userId) async {
    final cartRef = _db.collection('users').doc(userId).collection('cart');
    final snapshots = await cartRef.get();
    final batch = _db.batch();
    for (final doc in snapshots.docs) {
      batch.delete(doc.reference);
    }
    await batch.commit();
  }

  // Place order
  Future<void> placeOrder(String userId, List<CartItem> cartItems, double totalAmount) async {
    final orderId = 'FM-${(1000 + (DateTime.now().millisecond % 9000))}${DateTime.now().second}';
    final orderDoc = _db.collection('users').doc(userId).collection('orders').doc(orderId);
    
    final itemsData = cartItems.map((item) => {
      'productId': item.product.id,
      'productName': item.product.name,
      'price': item.product.price,
      'quantity': item.quantity,
      'colorValue': item.selectedColor.value,
      'size': item.selectedSize,
    }).toList();

    await orderDoc.set({
      'orderId': orderId,
      'items': itemsData,
      'totalAmount': totalAmount,
      'status': 'PROCESSING',
      'timestamp': FieldValue.serverTimestamp(),
    });
    
    // Also clear the cart
    await clearCart(userId);
  }

  // Stream of user orders
  Stream<List<Map<String, dynamic>>> getOrdersStream(String userId) {
    return _db
        .collection('users')
        .doc(userId)
        .collection('orders')
        .orderBy('timestamp', descending: true)
        .snapshots()
        .map((snapshot) {
          return snapshot.docs.map((doc) => doc.data()).toList();
        });
  }

  // Get/Create User Data
  Stream<DocumentSnapshot> getUserDataStream(String userId, String email) {
    final docRef = _db.collection('users').doc(userId);
    docRef.get().then((doc) {
      if (!doc.exists) {
        docRef.set({
          'userId': userId,
          'email': email,
          'displayName': email.split('@').first,
          'createdAt': FieldValue.serverTimestamp(),
        });
      }
    });
    return docRef.snapshots();
  }
}
