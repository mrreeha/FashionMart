import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/product.dart';
import '../data/mock_products.dart';

class DummyData {
  static const List<Product> products = mockProducts;
}

Future<void> migrateProductsToFirestore() async {
  print("Starting product migration to Firestore...");
  try {
    final firestore = FirebaseFirestore.instance;
    
    // Enable local persistence so writes resolve immediately to local cache
    try {
      firestore.settings = const Settings(
        persistenceEnabled: true,
      );
    } catch (settingsError) {
      print("Firestore settings/persistence configuration bypassed: $settingsError");
    }

    final batch = firestore.batch();
    for (final product in DummyData.products) {
      final docRef = firestore.collection('products').doc(product.id);
      batch.set(docRef, {
        'id': product.id,
        'brand': product.brand,
        'name': product.name,
        'price': product.price,
        'imageUrl': product.imageUrl,
        'rating': product.rating,
        'reviewCount': product.reviewCount,
        'description': product.description,
        'colors': product.colors.map((color) => color.value).toList(),
        'sizes': product.sizes,
        'lookIds': product.lookIds,
      });
    }

    await batch.commit();
    print("upload complete");
  } catch (e) {
    print("Error migrating data: $e");
  }
}
