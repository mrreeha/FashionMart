import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import '../models/cart_item.dart';
import '../models/product.dart';
import '../data/mock_products.dart';

class CartService {
  // Singleton pattern
  static final CartService _instance = CartService._internal();
  factory CartService() => _instance;
  
  CartService._internal() {
    // Populate with some default starting cart items for beautiful UX
    _cartNotifier.value = [
      CartItem(
        product: getProductById('rec_dress_01'), // Silk Wrap Midi Dress
        selectedColor: const Color(0xFF8B4513), // TAN
        selectedSize: 'M',
        quantity: 1,
      ),
      CartItem(
        product: getProductById('rec_tote_01'), // Classic Leather Tote
        selectedColor: const Color(0xFFD2B48C), // CAMEL
        selectedSize: 'One Size',
        quantity: 1,
      ),
      CartItem(
        product: getProductById('scarf_01'), // Cashmere Scarf
        selectedColor: const Color(0xFFF2EDE5), // OATMEAL
        selectedSize: 'One Size',
        quantity: 1,
      ),
    ];
  }

  final ValueNotifier<List<CartItem>> _cartNotifier = ValueNotifier<List<CartItem>>([]);

  ValueListenable<List<CartItem>> get cartListenable => _cartNotifier;

  List<CartItem> get items => _cartNotifier.value;

  void addToCart({
    required Product product,
    required Color color,
    required String size,
    int quantity = 1,
  }) {
    final currentList = List<CartItem>.from(_cartNotifier.value);
    
    // Check if item already exists with the same color and size
    final existingIndex = currentList.indexWhere(
      (item) => item.product.id == product.id && 
                item.selectedColor.value == color.value && 
                item.selectedSize == size
    );

    if (existingIndex >= 0) {
      currentList[existingIndex].quantity += quantity;
    } else {
      currentList.add(CartItem(
        product: product,
        selectedColor: color,
        selectedSize: size,
        quantity: quantity,
      ));
    }
    _cartNotifier.value = currentList;
  }

  void updateQuantity(CartItem item, int newQty) {
    if (newQty <= 0) {
      removeFromCart(item);
      return;
    }
    final currentList = List<CartItem>.from(_cartNotifier.value);
    final index = currentList.indexWhere((i) => i == item);
    if (index >= 0) {
      currentList[index].quantity = newQty;
      // Trigger update by setting a new reference
      _cartNotifier.value = currentList;
    }
  }

  void removeFromCart(CartItem item) {
    final currentList = List<CartItem>.from(_cartNotifier.value);
    currentList.removeWhere((i) => i == item);
    _cartNotifier.value = currentList;
  }

  void clearCart() {
    _cartNotifier.value = [];
  }

  double get subtotal {
    return _cartNotifier.value.fold(0.0, (sum, item) => sum + item.totalPrice);
  }

  double get discount {
    // 15% discount (matching WINTER15 code in static view)
    return subtotal > 0 ? subtotal * 0.15 : 0.0;
  }

  double get total {
    final sum = subtotal - discount;
    return sum < 0 ? 0.0 : sum;
  }
}
