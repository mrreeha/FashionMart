import 'package:flutter/material.dart';
import '../theme/app_colors.dart';
import '../theme/app_typography.dart';
import '../models/product.dart';
import '../data/mock_products.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../services/firestore_service.dart';

class ProductDetailsScreen extends StatefulWidget {
  final Product product;

  const ProductDetailsScreen({
    super.key,
    required this.product,
  });

  @override
  State<ProductDetailsScreen> createState() => _ProductDetailsScreenState();
}

class _ProductDetailsScreenState extends State<ProductDetailsScreen> {
  late Color selectedColor;
  late String selectedSize;
  int quantity = 1;

  @override
  void initState() {
    super.initState();
    selectedColor = widget.product.colors.isNotEmpty ? widget.product.colors.first : Colors.black;
    selectedSize = widget.product.sizes.contains('M')
        ? 'M'
        : (widget.product.sizes.isNotEmpty ? widget.product.sizes.first : 'S');
  }

  // When clicking on dynamic looks, if a new screen instance is pushed we get a new initState.
  // We can also react if the widget is updated (though not strictly needed for standard navigation).
  @override
  void didUpdateWidget(covariant ProductDetailsScreen oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.product.id != widget.product.id) {
      selectedColor = widget.product.colors.isNotEmpty ? widget.product.colors.first : Colors.black;
      selectedSize = widget.product.sizes.contains('M')
          ? 'M'
          : (widget.product.sizes.isNotEmpty ? widget.product.sizes.first : 'S');
      quantity = 1;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          children: [
            _buildHeroImage(context),
            _buildContentCard(),
            _buildCompleteTheLook(),
          ],
        ),
      ),
    );
  }

  Widget _buildHeroImage(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      height: 486,
      child: Stack(
        children: [
          Image.network(
            widget.product.imageUrl,
            fit: BoxFit.cover,
            width: double.infinity,
            height: double.infinity,
            errorBuilder: (context, error, stackTrace) => Container(
              color: AppColors.surfaceContainer,
              child: const Center(
                child: Icon(Icons.broken_image, size: 64, color: AppColors.outline),
              ),
            ),
          ),
          Positioned(
            top: MediaQuery.of(context).padding.top + 16,
            left: 24,
            right: 24,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                _buildCircularButton(Icons.arrow_back, () => Navigator.pop(context)),
                _buildCircularButton(Icons.share, () {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('Sharing this product link...'),
                      duration: Duration(seconds: 1),
                    ),
                  );
                }),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCircularButton(IconData icon, VoidCallback onPressed) {
    return InkWell(
      onTap: onPressed,
      child: Container(
        width: 40,
        height: 40,
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.2),
          shape: BoxShape.circle,
        ),
        child: Center(
          child: Icon(icon, color: Colors.white, size: 20),
        ),
      ),
    );
  }

  Widget _buildContentCard() {
    return Container(
      transform: Matrix4.translationValues(0.0, -24.0, 0.0),
      decoration: const BoxDecoration(
        color: AppColors.surfaceContainerLowest,
        borderRadius: BorderRadius.vertical(top: Radius.circular(12)),
        boxShadow: [
          BoxShadow(
            color: Color.fromRGBO(4, 36, 25, 0.05),
            blurRadius: 20,
            offset: Offset(0, -10),
          ),
        ],
      ),
      padding: const EdgeInsets.all(24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            widget.product.name,
            style: AppTypography.headlineH1.copyWith(color: AppColors.primary),
          ),
          const SizedBox(height: 8),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                widget.product.formattedPrice,
                style: AppTypography.headlineH2.copyWith(
                  color: AppColors.onSurface,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Row(
                children: [
                  ...List.generate(5, (index) {
                    final isFilled = index < widget.product.rating.floor();
                    return Icon(
                      isFilled ? Icons.star : Icons.star_border,
                      color: AppColors.tertiaryContainer,
                      size: 18,
                    );
                  }),
                  const SizedBox(width: 4),
                  Text(
                    '(${widget.product.reviewCount} Reviews)',
                    style: AppTypography.labelSm.copyWith(color: AppColors.outline),
                  ),
                ],
              ),
            ],
          ),
          const SizedBox(height: 32),
          _buildColorSelection(),
          const SizedBox(height: 32),
          _buildSizeSelection(),
          const SizedBox(height: 64),
          _buildQuantityAndAdd(),
          const SizedBox(height: 64),
          _buildAccordion(
            'Product Description',
            widget.product.description,
            true,
          ),
          const Divider(color: AppColors.outlineVariant),
          _buildAccordion(
            'Sustainability & Care',
            'Crafted with consideration for the environment. Dry clean only. Keep stored in a cool, dry garment bag to maintain shape and texture.',
            false,
          ),
        ],
      ),
    );
  }

  Widget _buildColorSelection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'COLOR',
          style: AppTypography.labelSm.copyWith(color: AppColors.outline, letterSpacing: 1.5),
        ),
        const SizedBox(height: 8),
        Row(
          children: widget.product.colors.map((color) {
            final isSelected = selectedColor == color;
            return Padding(
              padding: const EdgeInsets.only(right: 16),
              child: _buildColorDot(color, isSelected),
            );
          }).toList(),
        ),
      ],
    );
  }

  Widget _buildColorDot(Color color, bool isSelected) {
    return GestureDetector(
      onTap: () {
        setState(() {
          selectedColor = color;
        });
      },
      child: Container(
        width: 32,
        height: 32,
        decoration: BoxDecoration(
          color: color,
          shape: BoxShape.circle,
          border: isSelected
              ? Border.all(color: AppColors.primary, width: 2)
              : Border.all(color: Colors.grey.shade200, width: 1),
        ),
      ),
    );
  }

  Widget _buildSizeSelection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              'SIZE',
              style: AppTypography.labelSm.copyWith(color: AppColors.outline, letterSpacing: 1.5),
            ),
            Text(
              'Size Guide',
              style: AppTypography.labelSm.copyWith(
                color: AppColors.secondary,
                decoration: TextDecoration.underline,
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: widget.product.sizes.map((size) {
            final isSelected = selectedSize == size;
            return _buildSizeBox(size, isSelected);
          }).toList(),
        ),
      ],
    );
  }

  Widget _buildSizeBox(String size, bool isSelected) {
    return Expanded(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 4),
        child: GestureDetector(
          onTap: () {
            setState(() {
              selectedSize = size;
            });
          },
          child: Container(
            height: 48,
            decoration: BoxDecoration(
              color: isSelected ? AppColors.primaryContainer : Colors.transparent,
              borderRadius: BorderRadius.circular(24),
              border: isSelected ? null : Border.all(color: AppColors.outlineVariant),
            ),
            child: Center(
              child: Text(
                size,
                style: AppTypography.labelSm.copyWith(
                  color: isSelected ? AppColors.onPrimary : AppColors.onSurface,
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildQuantityAndAdd() {
    return Row(
      children: [
        Container(
          height: 56,
          padding: const EdgeInsets.symmetric(horizontal: 16),
          decoration: BoxDecoration(
            color: AppColors.surfaceContainerLow,
            borderRadius: BorderRadius.circular(28),
            border: Border.all(color: AppColors.outlineVariant.withOpacity(0.3)),
          ),
          child: Row(
            children: [
              GestureDetector(
                onTap: () {
                  if (quantity > 1) {
                    setState(() {
                      quantity--;
                    });
                  }
                },
                child: const Icon(Icons.remove, size: 20),
              ),
              const SizedBox(width: 16),
              Text(
                '$quantity',
                style: AppTypography.bodyMd.copyWith(fontWeight: FontWeight.bold),
              ),
              const SizedBox(width: 16),
              GestureDetector(
                onTap: () {
                  setState(() {
                    quantity++;
                  });
                },
                child: const Icon(Icons.add, size: 20),
              ),
            ],
          ),
        ),
        const SizedBox(width: 16),
        Expanded(
          child: ElevatedButton.icon(
            onPressed: () async {
              final user = FirebaseAuth.instance.currentUser;
              final userId = user?.uid ?? 'guest';
              await FirestoreService().addToCart(
                userId,
                widget.product,
                selectedColor,
                selectedSize,
                quantity: quantity,
              );
              if (mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    backgroundColor: AppColors.primary,
                    content: Text(
                      'Added $quantity × ${widget.product.name} to cart!',
                      style: AppTypography.bodyMd.copyWith(color: Colors.white),
                    ),
                    duration: const Duration(seconds: 2),
                  ),
                );
              }
            },
            icon: const Icon(Icons.shopping_bag, size: 20),
            label: const Text('Add to Cart'),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.primary,
              foregroundColor: AppColors.onPrimary,
              minimumSize: const Size(double.infinity, 56),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(28)),
              textStyle: AppTypography.bodyMd,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildAccordion(String title, String content, bool isExpanded) {
    return Theme(
      data: ThemeData(dividerColor: Colors.transparent),
      child: ExpansionTile(
        initiallyExpanded: isExpanded,
        tilePadding: EdgeInsets.zero,
        title: Text(
          title,
          style: AppTypography.labelSm.copyWith(color: AppColors.onSurface, letterSpacing: 1.5),
        ),
        iconColor: AppColors.onSurface,
        collapsedIconColor: AppColors.onSurface,
        children: content.isNotEmpty
            ? [
                Padding(
                  padding: const EdgeInsets.only(bottom: 16),
                  child: Text(
                    content,
                    style: AppTypography.bodyMd.copyWith(color: AppColors.onSurfaceVariant),
                  ),
                ),
              ]
            : [],
      ),
    );
  }

  Widget _buildCompleteTheLook() {
    if (widget.product.lookIds.isEmpty) return const SizedBox.shrink();

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24).copyWith(bottom: 32),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Complete the Look',
            style: AppTypography.headlineH2.copyWith(color: AppColors.primary),
          ),
          const SizedBox(height: 16),
          StreamBuilder<List<Product>>(
            stream: FirestoreService().getProductsByIdsStream(widget.product.lookIds),
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return const SizedBox(
                  height: 100,
                  child: Center(child: CircularProgressIndicator(color: AppColors.primary)),
                );
              }
              final lookProducts = snapshot.data ?? [];
              if (lookProducts.isEmpty) return const SizedBox.shrink();
              return SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: lookProducts.map((lookProduct) {
                    return Padding(
                      padding: const EdgeInsets.only(right: 16),
                      child: _buildMiniCard(context, lookProduct),
                    );
                  }).toList(),
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _buildMiniCard(BuildContext context, Product lookProduct) {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => ProductDetailsScreen(product: lookProduct),
          ),
        );
      },
      child: SizedBox(
        width: 160,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              height: 200,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                image: DecorationImage(
                  image: NetworkImage(lookProduct.imageUrl),
                  fit: BoxFit.cover,
                ),
              ),
            ),
            const SizedBox(height: 8),
            Text(
              lookProduct.name,
              style: AppTypography.labelSm.copyWith(fontSize: 13, color: AppColors.onSurface),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
            Text(
              lookProduct.formattedPrice,
              style: AppTypography.bodyMd.copyWith(
                color: AppColors.secondary,
                fontWeight: FontWeight.bold,
                fontSize: 14,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
