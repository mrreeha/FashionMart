import 'package:flutter/material.dart';
import 'home_screen.dart';
import 'product_listing_screen.dart'; // used for search/categories
import 'cart_screen.dart';
import 'profile_screen.dart';
import 'editorial_screen.dart';

class MainScreen extends StatefulWidget {
  const MainScreen({super.key});

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  int _currentIndex = 0;

  final List<Widget> _screens = [
    const HomeScreen(),
    const ProductListingScreen(), // Placeholder for Search
    const EditorialScreen(), // Replaced Wishlist with Editorial
    const CartScreen(),
    const ProfileScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(
        index: _currentIndex,
        children: _screens,
      ),
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          border: Border(top: BorderSide(color: Colors.grey.shade100)),
          boxShadow: [
            BoxShadow(
              color: const Color.fromRGBO(27, 58, 45, 0.05),
              blurRadius: 4,
              offset: const Offset(0, -1),
            )
          ],
        ),
        child: BottomNavigationBar(
          currentIndex: _currentIndex,
          onTap: (index) {
            setState(() {
              _currentIndex = index;
            });
          },
          type: BottomNavigationBarType.fixed,
          backgroundColor: Colors.white,
          selectedItemColor: const Color(0xFF064E3B), // emerald-900
          unselectedItemColor: const Color(0xFFA1A1AA), // zinc-400
          selectedLabelStyle: TextStyle(
            fontFamily: 'Noto Serif',
            fontSize: 10,
            fontWeight: FontWeight.bold,
            letterSpacing: -0.5,
          ),
          unselectedLabelStyle: TextStyle(
            fontFamily: 'Noto Serif',
            fontSize: 10,
            fontWeight: FontWeight.normal,
            letterSpacing: -0.5,
          ),
          elevation: 0,
          items: const [
            BottomNavigationBarItem(
              icon: Icon(Icons.home_outlined),
              activeIcon: Icon(Icons.home),
              label: 'HOME',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.search_outlined),
              activeIcon: Icon(Icons.search),
              label: 'SEARCH',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.auto_awesome_outlined),
              activeIcon: Icon(Icons.auto_awesome),
              label: 'EDITORIAL',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.shopping_bag_outlined),
              activeIcon: Icon(Icons.shopping_bag),
              label: 'CART',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.person_outline),
              activeIcon: Icon(Icons.person),
              label: 'PROFILE',
            ),
          ],
        ),
      ),
    );
  }
}
