import 'package:flutter/material.dart';
import '../theme/app_colors.dart';
import '../theme/app_typography.dart';
import '../widgets/top_app_bar.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../models/cart_item.dart';
import '../services/firestore_service.dart';

class CartScreen extends StatelessWidget {
  const CartScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    final userId = user?.uid ?? 'guest';
    final firestoreService = FirestoreService();

    return Scaffold(
      appBar: const CustomAppBar(showBackButton: true),
      body: StreamBuilder<List<CartItem>>(
        stream: firestoreService.getCartStream(userId),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator(color: AppColors.primary));
          }
          final items = snapshot.data ?? [];
          if (items.isEmpty) {
            return _buildEmptyCart(context);
          }
          return SingleChildScrollView(
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 32).copyWith(bottom: 120),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Your Cart', style: AppTypography.headlineH2.copyWith(color: AppColors.primary)),
                const SizedBox(height: 32),
                _buildCartItems(context, userId, firestoreService, items),
                const SizedBox(height: 32),
                _buildOrderSummary(items),
                const SizedBox(height: 24),
                ElevatedButton(
                  onPressed: () {
                    Navigator.pushNamed(context, '/checkout');
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.primaryContainer,
                    foregroundColor: AppColors.onPrimary,
                    minimumSize: const Size(double.infinity, 56),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(28)),
                    elevation: 4,
                  ),
                  child: Text(
                    'PROCEED TO CHECKOUT',
                    style: AppTypography.labelSm.copyWith(letterSpacing: 2),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _buildEmptyCart(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(
              Icons.shopping_bag_outlined,
              size: 96,
              color: AppColors.outlineVariant,
            ),
            const SizedBox(height: 24),
            Text(
              'Your shopping bag is empty.',
              style: AppTypography.headlineH2.copyWith(color: AppColors.primary),
            ),
            const SizedBox(height: 8),
            Text(
              'Explore our curated collections to find your perfect styles.',
              style: AppTypography.bodyMd.copyWith(color: AppColors.onSurfaceVariant),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 32),
            ElevatedButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.primary,
                foregroundColor: Colors.white,
                minimumSize: const Size(200, 48),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
              ),
              child: Text('CONTINUE SHOPPING', style: AppTypography.labelSm),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCartItems(
    BuildContext context,
    String userId,
    FirestoreService firestoreService,
    List<CartItem> items,
  ) {
    return Column(
      children: items.map((item) {
        final isLast = item == items.last;
        return Column(
          children: [
            _buildCartItem(context, userId, firestoreService, item),
            if (!isLast) const Divider(color: AppColors.surfaceVariant, height: 32),
          ],
        );
      }).toList(),
    );
  }

  Widget _buildCartItem(
    BuildContext context,
    String userId,
    FirestoreService firestoreService,
    CartItem item,
  ) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          width: 96,
          height: 128,
          decoration: BoxDecoration(
            color: AppColors.surfaceContainer,
            borderRadius: BorderRadius.circular(8),
            image: DecorationImage(
              image: NetworkImage(item.product.imageUrl),
              fit: BoxFit.cover,
            ),
          ),
        ),
        const SizedBox(width: 16),
        Expanded(
          child: SizedBox(
            height: 128,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            item.product.name,
                            style: AppTypography.headlineH2.copyWith(fontSize: 18, color: AppColors.primary),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                          const SizedBox(height: 4),
                          Text(item.specs, style: AppTypography.labelSm.copyWith(color: AppColors.outline)),
                        ],
                      ),
                    ),
                    IconButton(
                      padding: EdgeInsets.zero,
                      constraints: const BoxConstraints(),
                      icon: const Icon(Icons.delete_outline, color: AppColors.outline, size: 20),
                      onPressed: () async {
                        await firestoreService.removeFromCart(userId, item.product.id, item.selectedColor, item.selectedSize);
                        if (context.mounted) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              content: Text('${item.product.name} removed from bag.'),
                              duration: const Duration(seconds: 1),
                            ),
                          );
                        }
                      },
                    ),
                  ],
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                      decoration: BoxDecoration(
                        border: Border.all(color: AppColors.outlineVariant),
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: Row(
                        children: [
                          GestureDetector(
                            onTap: () async {
                              await firestoreService.updateCartQuantity(userId, item.product.id, item.selectedColor, item.selectedSize, item.quantity - 1);
                            },
                            child: const Icon(Icons.remove, size: 16, color: AppColors.primary),
                          ),
                          const SizedBox(width: 16),
                          Text('${item.quantity}', style: AppTypography.labelSm),
                          const SizedBox(width: 16),
                          GestureDetector(
                            onTap: () async {
                              await firestoreService.updateCartQuantity(userId, item.product.id, item.selectedColor, item.selectedSize, item.quantity + 1);
                            },
                            child: const Icon(Icons.add, size: 16, color: AppColors.primary),
                          ),
                        ],
                      ),
                    ),
                    Text(
                      item.formattedTotalPrice,
                      style: AppTypography.headlineH2.copyWith(fontSize: 16, color: AppColors.primary),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildOrderSummary(List<CartItem> items) {
    final subtotal = items.fold(0.0, (sum, item) => sum + item.totalPrice);
    final discount = subtotal > 0 ? subtotal * 0.15 : 0.0;
    final total = subtotal - discount;

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.surfaceContainerLow,
        borderRadius: BorderRadius.circular(12),
        boxShadow: const [
          BoxShadow(
            color: Color.fromRGBO(27, 58, 45, 0.04),
            blurRadius: 8,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('ORDER SUMMARY', style: AppTypography.labelSm.copyWith(color: AppColors.outline, letterSpacing: 1.5)),
          const SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('Subtotal', style: AppTypography.bodyMd.copyWith(color: AppColors.onSurfaceVariant)),
              Text('\$${subtotal.toStringAsFixed(2)}', style: AppTypography.labelSm.copyWith(color: AppColors.primary)),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('Shipping', style: AppTypography.bodyMd.copyWith(color: AppColors.onSurfaceVariant)),
              Text('Free', style: AppTypography.labelSm.copyWith(color: AppColors.primary)),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('Discount (WINTER15)', style: AppTypography.bodyMd.copyWith(color: AppColors.onSurfaceVariant)),
              Text('-\$${discount.toStringAsFixed(2)}', style: AppTypography.labelSm.copyWith(color: AppColors.secondary)),
            ],
          ),
          const SizedBox(height: 16),
          const Divider(color: AppColors.outlineVariant),
          const SizedBox(height: 12),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('Total', style: AppTypography.headlineH2.copyWith(fontSize: 20, color: AppColors.primary)),
              Text('\$${total.toStringAsFixed(2)}', style: AppTypography.headlineH1.copyWith(fontSize: 24, color: AppColors.primary)),
            ],
          ),
        ],
      ),
    );
  }
}
