import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../theme/app_colors.dart';
import '../theme/app_typography.dart';
import '../widgets/top_app_bar.dart';
import '../services/auth_service.dart';
import '../services/firestore_service.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'order_history_screen.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final _authService = AuthService();
  bool _notificationsEnabled = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const CustomAppBar(),
      body: StreamBuilder<User?>(
        stream: _authService.authStateChanges,
        builder: (context, snapshot) {
          final user = snapshot.data;
          
          if (user == null) {
            return _buildLoggedOutView(context);
          }

          return SingleChildScrollView(
            padding: const EdgeInsets.only(bottom: 120),
            child: Column(
              children: [
                _buildProfileHeader(user),
                const SizedBox(height: 32),
                _buildStatsRow(user),
                const SizedBox(height: 32),
                _buildMenuList(context),
                const SizedBox(height: 64),
                _buildNewsletterUpsell(),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _buildLoggedOutView(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(
              Icons.account_circle_outlined,
              size: 96,
              color: AppColors.outlineVariant,
            ),
            const SizedBox(height: 24),
            Text(
              'Join FASHION MART',
              style: AppTypography.headlineH2.copyWith(color: AppColors.primary),
            ),
            const SizedBox(height: 12),
            Text(
              'Log in to track your orders, manage your delivery addresses, and enjoy premium member benefits.',
              style: AppTypography.bodyMd.copyWith(color: AppColors.onSurfaceVariant),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 32),
            ElevatedButton(
              onPressed: () {
                Navigator.pushNamed(context, '/login');
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.primary,
                foregroundColor: Colors.white,
                minimumSize: const Size(220, 52),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(26)),
              ),
              child: Text(
                'LOG IN / SIGN UP',
                style: AppTypography.labelSm.copyWith(letterSpacing: 2, color: Colors.white),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildProfileHeader(User user) {
    return StreamBuilder<DocumentSnapshot>(
      stream: FirestoreService().getUserDataStream(user.uid, user.email ?? ''),
      builder: (context, snapshot) {
        final data = snapshot.data?.data() as Map<String, dynamic>?;
        final email = data?['email'] ?? user.email ?? 'premium.member@f-mart.com';
        final rawName = data?['displayName'] ?? user.displayName ?? (user.email != null ? user.email!.split('@').first : 'Guest User');
        final formattedName = rawName.split('.').map((s) => s.isNotEmpty ? s[0].toUpperCase() + s.substring(1) : '').join(' ');

        return Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 32),
          child: Column(
            children: [
              Stack(
                children: [
                  Container(
                    width: 128,
                    height: 128,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(color: Colors.white, width: 4),
                      boxShadow: const [
                        BoxShadow(color: Colors.black12, blurRadius: 4),
                      ],
                      image: const DecorationImage(
                        image: NetworkImage('https://lh3.googleusercontent.com/aida-public/AB6AXuASjSO1qV8YQLlHAgdvCcBvK4Yx_BQYMlYwwQEAKG53umDOPjMiSs9fR7t6QQ6pJL_glG8K_n925TAV6D37FXTfpcHtDSIFgQQ86t-kwcAX46zj-bB9Kg1q0-WH8vEjFxqe1omtlv1BvSHDfK0HUUGX9Q63k2vyfhTWwSW015yYITGcdZTTKQs-y5x-cwUcYiUrofxbDvWGcezLWo3ocm4IUphryByqPVSrnNbBVk9xzT1h7-j2FH5NmQxX5RvvI2EsBndpD3AuLbc'),
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                  Positioned(
                    bottom: 0,
                    right: 0,
                    child: Container(
                      padding: const EdgeInsets.all(8),
                      decoration: const BoxDecoration(
                        color: AppColors.primary,
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(Icons.edit, color: Colors.white, size: 16),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              Text(formattedName, style: AppTypography.headlineH1.copyWith(color: AppColors.primary)),
              const SizedBox(height: 4),
              Text(email, style: AppTypography.labelSm.copyWith(color: AppColors.secondary, letterSpacing: 1.5)),
            ],
          ),
        );
      },
    );
  }

  Widget _buildStatsRow(User user) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          boxShadow: const [
            BoxShadow(
              color: Color.fromRGBO(27, 58, 45, 0.04),
              blurRadius: 12,
              offset: Offset(0, 4),
            ),
          ],
        ),
        child: StreamBuilder<List<Map<String, dynamic>>>(
          stream: FirestoreService().getOrdersStream(user.uid),
          builder: (context, snapshot) {
            final count = snapshot.data?.length ?? 0;
            final countStr = count.toString().padLeft(2, '0');
            return Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _buildStatItem(
                  countStr,
                  'Orders',
                  true,
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => const OrderHistoryScreen()),
                  ),
                ),
                _buildStatItem('48', 'Wishlist', true),
                _buildStatItem('05', 'Reviews', false),
              ],
            );
          },
        ),
      ),
    );
  }

  Widget _buildStatItem(String count, String label, bool showBorder, {VoidCallback? onTap}) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        behavior: HitTestBehavior.opaque,
        child: Container(
          decoration: showBorder
              ? const BoxDecoration(
                  border: Border(right: BorderSide(color: AppColors.surfaceContainer)),
                )
              : null,
          child: Column(
            children: [
              Text(count, style: AppTypography.headlineH2.copyWith(color: AppColors.primary)),
              Text(label.toUpperCase(), style: AppTypography.labelSm.copyWith(color: AppColors.outline)),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildMenuList(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24),
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          boxShadow: const [
            BoxShadow(
              color: Color.fromRGBO(27, 58, 45, 0.03),
              blurRadius: 8,
              offset: Offset(0, 2),
            ),
          ],
        ),
        child: Column(
          children: [
            _buildMenuItem(
              Icons.shopping_bag,
              'My Orders',
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const OrderHistoryScreen()),
              ),
            ),
            _buildMenuItem(Icons.location_on, 'Addresses', onTap: () => _showAddressesSheet(context)),
            _buildMenuItem(Icons.credit_card, 'Payment Methods', onTap: () => _showPaymentsSheet(context)),
            _buildMenuItem(
              Icons.notifications,
              'Notifications',
              hasToggle: true,
              toggleValue: _notificationsEnabled,
              onToggleChanged: (val) {
                setState(() {
                  _notificationsEnabled = val;
                });
              },
            ),
            _buildMenuItem(Icons.headset_mic, 'Help & Support', onTap: () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Support is available 24/7. Contacting agent...')),
              );
            }),
            _buildMenuItem(Icons.logout, 'Logout', isDestructive: true, onTap: () async {
              final navigator = Navigator.of(context);
              await _authService.signOut();
              navigator.pushNamedAndRemoveUntil('/login', (route) => false);
            }),
          ],
        ),
      ),
    );
  }

  Widget _buildMenuItem(
    IconData icon,
    String title, {
    bool hasToggle = false,
    bool toggleValue = false,
    ValueChanged<bool>? onToggleChanged,
    bool isDestructive = false,
    VoidCallback? onTap,
  }) {
    Color iconColor = isDestructive ? AppColors.error : AppColors.primaryContainer;
    Color iconBgColor = isDestructive ? AppColors.errorContainer.withOpacity(0.2) : AppColors.primaryContainer.withOpacity(0.1);
    Color textColor = isDestructive ? AppColors.error : AppColors.onSurface;

    return InkWell(
      onTap: hasToggle ? null : (onTap ?? () {}),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: const BoxDecoration(
          border: Border(bottom: BorderSide(color: AppColors.surfaceContainer)),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(
              children: [
                Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: iconBgColor,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Icon(icon, color: iconColor, size: 20),
                ),
                const SizedBox(width: 16),
                Text(title, style: AppTypography.bodyMd.copyWith(fontWeight: FontWeight.bold, color: textColor)),
              ],
            ),
            if (hasToggle)
              Switch(
                value: toggleValue,
                onChanged: onToggleChanged,
                activeColor: AppColors.secondary,
              )
            else if (!isDestructive)
              const Icon(Icons.chevron_right, color: AppColors.outline),
          ],
        ),
      ),
    );
  }

  Widget _buildNewsletterUpsell() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: AppColors.primaryContainer,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Stack(
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Exclusive Curation', style: AppTypography.headlineH2.copyWith(color: Colors.white, fontSize: 18)),
                const SizedBox(height: 8),
                Text(
                  'Join our editorial newsletter for early access to seasonal drops.',
                  style: AppTypography.bodyMd.copyWith(color: AppColors.onPrimaryContainer, fontSize: 14),
                ),
                const SizedBox(height: 16),
                ElevatedButton(
                  onPressed: () {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('Successfully subscribed to exclusive curation newsletters!'),
                        duration: Duration(seconds: 2),
                      ),
                    );
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.secondary,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                  ),
                  child: Text('SUBSCRIBE', style: AppTypography.labelSm),
                ),
              ],
            ),
            Positioned(
              right: -20,
              top: -20,
              child: Container(
                width: 128,
                height: 128,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.white.withOpacity(0.05),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showOrdersSheet(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    final userId = user?.uid ?? 'guest';
    final firestoreService = FirestoreService();

    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) {
        return Padding(
          padding: const EdgeInsets.all(24.0),
          child: StreamBuilder<List<Map<String, dynamic>>>(
            stream: firestoreService.getOrdersStream(userId),
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return const SizedBox(
                  height: 150,
                  child: Center(child: CircularProgressIndicator(color: AppColors.primary)),
                );
              }
              
              final orders = snapshot.data ?? [];

              return Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('My Orders', style: AppTypography.headlineH2.copyWith(color: AppColors.primary)),
                  const SizedBox(height: 20),
                  if (orders.isEmpty)
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 24),
                      child: Center(
                        child: Text(
                          'No orders placed yet.',
                          style: AppTypography.bodyMd.copyWith(color: AppColors.outline),
                        ),
                      ),
                    )
                  else
                    Flexible(
                      child: ListView.separated(
                        shrinkWrap: true,
                        itemCount: orders.length,
                        separatorBuilder: (context, index) => const Divider(height: 24),
                        itemBuilder: (context, index) {
                          final order = orders[index];
                          final orderId = order['orderId'] ?? '';
                          final items = order['items'] as List<dynamic>? ?? [];
                          String itemText = 'Product';
                          if (items.isNotEmpty) {
                            final firstItem = items[0] as Map<String, dynamic>?;
                            if (firstItem != null) {
                              itemText = firstItem['productName'] as String? ?? 'Product';
                            }
                          }
                          final displayItemText = items.length > 1
                              ? '$itemText + ${items.length - 1} more'
                              : itemText;
                          final totalAmount = (order['totalAmount'] as num?)?.toDouble() ?? 0.0;
                          final status = order['status'] ?? 'PROCESSING';
                          final statusColor = status == 'DELIVERED' ? Colors.green : Colors.orange;

                          return _buildOrderTile(
                            '#$orderId',
                            displayItemText,
                            '\$${totalAmount.toStringAsFixed(2)}',
                            status,
                            statusColor,
                          );
                        },
                      ),
                    ),
                  const SizedBox(height: 24),
                ],
              );
            },
          ),
        );
      },
    );
  }

  Widget _buildOrderTile(String orderId, String item, String price, String status, Color statusColor) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(orderId, style: AppTypography.bodyMd.copyWith(fontWeight: FontWeight.bold)),
            const SizedBox(height: 4),
            Text(item, style: AppTypography.labelSm.copyWith(color: AppColors.outline)),
          ],
        ),
        Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Text(price, style: AppTypography.bodyMd.copyWith(fontWeight: FontWeight.bold)),
            const SizedBox(height: 4),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
              decoration: BoxDecoration(
                color: statusColor.withOpacity(0.1),
                borderRadius: BorderRadius.circular(4),
              ),
              child: Text(
                status,
                style: AppTypography.labelSm.copyWith(color: statusColor, fontSize: 10),
              ),
            ),
          ],
        ),
      ],
    );
  }

  void _showAddressesSheet(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) {
        return Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Saved Addresses', style: AppTypography.headlineH2.copyWith(color: AppColors.primary)),
              const SizedBox(height: 20),
              Row(
                children: [
                  const Icon(Icons.home_outlined, color: AppColors.primary),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Home', style: AppTypography.bodyMd.copyWith(fontWeight: FontWeight.bold)),
                        const SizedBox(height: 4),
                        Text('742 Evergreen Terrace, Springfield, OR 97403', style: AppTypography.labelSm.copyWith(color: AppColors.outline)),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 24),
            ],
          ),
        );
      },
    );
  }

  void _showPaymentsSheet(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) {
        return Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Payment Methods', style: AppTypography.headlineH2.copyWith(color: AppColors.primary)),
              const SizedBox(height: 20),
              Row(
                children: [
                  const Icon(Icons.credit_card, color: AppColors.primary),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Visa ending in 4242', style: AppTypography.bodyMd.copyWith(fontWeight: FontWeight.bold)),
                        const SizedBox(height: 4),
                        Text('Expires 12/28', style: AppTypography.labelSm.copyWith(color: AppColors.outline)),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 24),
            ],
          ),
        );
      },
    );
  }
}
