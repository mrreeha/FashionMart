import 'package:flutter/material.dart';
import '../theme/app_colors.dart';
import '../theme/app_typography.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../models/cart_item.dart';
import '../services/firestore_service.dart';
import 'order_history_screen.dart';

class CheckoutScreen extends StatelessWidget {
  const CheckoutScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    final userId = user?.uid ?? 'guest';
    final firestoreService = FirestoreService();

    return StreamBuilder<List<CartItem>>(
      stream: firestoreService.getCartStream(userId),
      builder: (context, snapshot) {
        final items = snapshot.data ?? [];
        final subtotal = items.fold(0.0, (sum, item) => sum + item.totalPrice);
        final discount = subtotal > 0 ? subtotal * 0.15 : 0.0;
        final total = subtotal - discount;

        return Scaffold(
          appBar: _buildAppBar(context),
          body: SingleChildScrollView(
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 32).copyWith(bottom: 120),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildProgressSteps(),
                const SizedBox(height: 32),
                _buildDeliveryAddress(),
                const SizedBox(height: 32),
                _buildDeliveryMethod(),
                const SizedBox(height: 32),
                _buildPaymentMethod(),
                const SizedBox(height: 32),
                _buildOrderSummary(context, items, subtotal, discount, total),
              ],
            ),
          ),
        );
      },
    );
  }

  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return PreferredSize(
      preferredSize: const Size.fromHeight(64),
      child: Container(
        height: 64 + MediaQuery.of(context).padding.top,
        padding: EdgeInsets.only(top: MediaQuery.of(context).padding.top, left: 24, right: 24),
        decoration: BoxDecoration(
          color: Colors.white,
          border: Border(bottom: BorderSide(color: Colors.grey.shade100)),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            IconButton(
              icon: const Icon(Icons.arrow_back, color: Color(0xFF064E3B)),
              onPressed: () => Navigator.pop(context),
              padding: EdgeInsets.zero,
              constraints: const BoxConstraints(),
            ),
            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text('CHECKOUT', style: AppTypography.headlineH2.copyWith(fontSize: 14, fontWeight: FontWeight.w900, color: const Color(0xFF022C22), letterSpacing: 2)),
                Text('STEP 1 OF 3', style: AppTypography.labelSm.copyWith(fontSize: 10, color: AppColors.onSurfaceVariant, letterSpacing: 2)),
              ],
            ),
            IconButton(
              icon: const Icon(Icons.shopping_bag_outlined, color: Color(0xFF064E3B)),
              onPressed: () {},
              padding: EdgeInsets.zero,
              constraints: const BoxConstraints(),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildProgressSteps() {
    return Row(
      children: [
        _buildStep('Shipping', AppColors.primaryContainer, true),
        const SizedBox(width: 8),
        _buildStep('Payment', AppColors.surfaceContainerHigh, false),
        const SizedBox(width: 8),
        _buildStep('Review', AppColors.surfaceContainerHigh, false),
      ],
    );
  }

  Widget _buildStep(String title, Color color, bool isActive) {
    return Expanded(
      child: Column(
        children: [
          Container(
            height: 6,
            decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(3)),
          ),
          const SizedBox(height: 8),
          Text(
            title,
            style: AppTypography.labelSm.copyWith(color: isActive ? AppColors.primaryContainer : AppColors.outline),
          ),
        ],
      ),
    );
  }

  Widget _buildDeliveryAddress() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text('Delivery Address', style: AppTypography.headlineH2.copyWith(color: AppColors.primary)),
            Text('Add New Address', style: AppTypography.labelSm.copyWith(color: AppColors.secondary, decoration: TextDecoration.underline)),
          ],
        ),
        const SizedBox(height: 16),
        _buildTextField('FULL NAME', 'Julianne Moore'),
        const SizedBox(height: 16),
        _buildTextField('PHONE NUMBER', '+1 (555) 000-0000'),
        const SizedBox(height: 16),
        _buildTextField('SHIPPING ADDRESS', '742 Evergreen Terrace, Springfield, OR 97403', maxLines: 3),
      ],
    );
  }

  Widget _buildTextField(String label, String placeholder, {int maxLines = 1}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: AppTypography.labelSm.copyWith(color: AppColors.onSurfaceVariant)),
        const SizedBox(height: 8),
        TextField(
          maxLines: maxLines,
          decoration: InputDecoration(
            hintText: placeholder,
            hintStyle: AppTypography.bodyMd,
            filled: true,
            fillColor: AppColors.surfaceContainerLow,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8),
              borderSide: BorderSide(color: AppColors.outlineVariant),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8),
              borderSide: BorderSide(color: AppColors.outlineVariant),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8),
              borderSide: const BorderSide(color: AppColors.secondary),
            ),
            contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
          ),
        ),
      ],
    );
  }

  Widget _buildDeliveryMethod() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Delivery Method', style: AppTypography.headlineH2.copyWith(color: AppColors.primary)),
        const SizedBox(height: 16),
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: AppColors.primaryContainer.withOpacity(0.05),
            border: Border.all(color: AppColors.primaryContainer, width: 2),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Container(
                    width: 20,
                    height: 20,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      shape: BoxShape.circle,
                      border: Border.all(color: AppColors.primaryContainer, width: 4),
                    ),
                  ),
                  const SizedBox(width: 16),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Standard Shipping', style: AppTypography.bodyMd.copyWith(fontWeight: FontWeight.bold, color: AppColors.primary)),
                      Text('3-5 Business Days', style: AppTypography.labelSm.copyWith(color: AppColors.onSurfaceVariant)),
                    ],
                  ),
                ],
               ),
              Text('FREE', style: AppTypography.labelSm.copyWith(fontWeight: FontWeight.bold, color: AppColors.primary)),
            ],
          ),
        ),
        const SizedBox(height: 8),
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.white,
            border: Border.all(color: AppColors.outlineVariant),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Container(
                    width: 20,
                    height: 20,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(color: AppColors.outlineVariant),
                    ),
                  ),
                  const SizedBox(width: 16),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Express Shipping', style: AppTypography.bodyMd.copyWith(fontWeight: FontWeight.bold, color: AppColors.primary)),
                      Text('1-2 Business Days', style: AppTypography.labelSm.copyWith(color: AppColors.onSurfaceVariant)),
                    ],
                  ),
                ],
              ),
              Text('\$9.99', style: AppTypography.labelSm.copyWith(fontWeight: FontWeight.bold, color: AppColors.primary)),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildPaymentMethod() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Payment Method', style: AppTypography.headlineH2.copyWith(color: AppColors.primary)),
        const SizedBox(height: 16),
        Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: AppColors.primaryContainer,
            borderRadius: BorderRadius.circular(12),
            boxShadow: [
              BoxShadow(color: Colors.black.withOpacity(0.1), blurRadius: 10, offset: const Offset(0, 4)),
            ],
          ),
          child: Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Icon(Icons.credit_card, color: Colors.white, size: 36),
                  Text('CREDIT CARD', style: AppTypography.labelSm.copyWith(color: Colors.white.withOpacity(0.7))),
                ],
              ),
              const SizedBox(height: 24),
              _buildDarkTextField('CARD NUMBER', '**** **** **** 4242'),
              const SizedBox(height: 16),
              Row(
                children: [
                  Expanded(child: _buildDarkTextField('EXPIRY', 'MM/YY')),
                  const SizedBox(width: 16),
                  Expanded(child: _buildDarkTextField('CVV', '***')),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: 8),
        _buildAlternativePayment('PayPal', Icons.account_balance_wallet),
        const SizedBox(height: 8),
        _buildAlternativePayment('Apple Pay', Icons.contactless),
      ],
    );
  }

  Widget _buildDarkTextField(String label, String placeholder) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: const TextStyle(color: Colors.white60, fontSize: 10, letterSpacing: 2, fontWeight: FontWeight.bold)),
        const SizedBox(height: 4),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.1),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Text(
            placeholder,
            style: const TextStyle(color: Colors.white, fontFamily: 'monospace', fontSize: 14),
          ),
        ),
      ],
    );
  }

  Widget _buildAlternativePayment(String name, IconData icon) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(color: AppColors.outlineVariant),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              Container(
                width: 20,
                height: 20,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(color: AppColors.outlineVariant),
                ),
              ),
              const SizedBox(width: 16),
              Text(name, style: AppTypography.bodyMd.copyWith(fontWeight: FontWeight.bold, color: AppColors.primary)),
            ],
          ),
          Icon(icon, color: AppColors.onSurfaceVariant),
        ],
      ),
    );
  }

  Widget _buildOrderSummary(
    BuildContext context,
    List<CartItem> items,
    double subtotal,
    double discount,
    double total,
  ) {
    final user = FirebaseAuth.instance.currentUser;
    final userId = user?.uid ?? 'guest';
    final firestoreService = FirestoreService();

    return Container(
      padding: const EdgeInsets.only(top: 16),
      decoration: const BoxDecoration(
        border: Border(top: BorderSide(color: AppColors.surfaceContainerHighest)),
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('Subtotal', style: AppTypography.bodyMd.copyWith(color: AppColors.onSurfaceVariant)),
              Text('\$${subtotal.toStringAsFixed(2)}', style: AppTypography.bodyMd.copyWith(fontWeight: FontWeight.bold)),
            ],
          ),
          if (discount > 0) ...[
            const SizedBox(height: 8),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('Discount (WINTER15)', style: AppTypography.bodyMd.copyWith(color: AppColors.onSurfaceVariant)),
                Text('-\$${discount.toStringAsFixed(2)}', style: AppTypography.bodyMd.copyWith(color: AppColors.secondary, fontWeight: FontWeight.bold)),
              ],
            ),
          ],
          const SizedBox(height: 8),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('Shipping', style: AppTypography.bodyMd.copyWith(color: AppColors.onSurfaceVariant)),
              Text('FREE', style: AppTypography.bodyMd.copyWith(color: AppColors.secondary, fontWeight: FontWeight.bold)),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('Total', style: AppTypography.headlineH2),
              Text('\$${total.toStringAsFixed(2)}', style: AppTypography.headlineH2.copyWith(color: AppColors.primary)),
            ],
          ),
          const SizedBox(height: 24),
          ElevatedButton(
            onPressed: () async {
              if (items.isEmpty) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('Your cart is empty. Cannot place order.'),
                    backgroundColor: AppColors.error,
                  ),
                );
                return;
              }
              // Place order in Firestore
              await firestoreService.placeOrder(userId, items, total);
              
              // Show beautiful success SnackBar
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  backgroundColor: AppColors.primary,
                  content: Text('Order placed successfully! Thank you for shopping with FASHION MART.'),
                  duration: Duration(seconds: 3),
                ),
              );
              Navigator.popUntil(context, (route) => route.isFirst);
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const OrderHistoryScreen()),
              );
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.primaryContainer,
              foregroundColor: Colors.white,
              minimumSize: const Size(double.infinity, 56),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(28)),
              elevation: 4,
            ),
            child: Text(
              'PLACE ORDER',
              style: AppTypography.labelSm.copyWith(letterSpacing: 2),
            ),
          ),
        ],
      ),
    );
  }
}
