import 'package:flutter/material.dart';
import '../theme/app_colors.dart';
import '../theme/app_typography.dart';
import '../widgets/top_app_bar.dart';
import 'product_listing_screen.dart';

class EditorialScreen extends StatelessWidget {
  const EditorialScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const CustomAppBar(),
      body: ListView(
        padding: const EdgeInsets.only(bottom: 120),
        children: [
          _buildEditorialBanner(
            context,
            'https://lh3.googleusercontent.com/aida-public/AB6AXuAv5m2Z5-i1QXugqaBdGpfZyxjMgCVYaCR8p6EZTuH-38lHgQEEaUlfFErz37F2ulE3R_tdQ83aMy24JMP8-2diLuLBDW7iNkGdfRIMSn-ZFdp0SxSnfp1MgkCklvfDQM5u1d0Q1pZZ-RCUNGDCcaIo76T-ylseZ6iFvly_iLKznWhHDmvxIEx2A0i5jUDVFbbyOQhaNDtaDoKloYeGCTZ3skt_K82nhePXnVkrqWSS5WcV1ytXkL1SSKcbaSaxzMyBOk94wus8oZY',
            'MOODY MINIMALISM',
            'The new structural aesthetics of modern luxury.',
          ),
          const SizedBox(height: 32),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24),
            child: _buildContainedBanner(
              'https://lh3.googleusercontent.com/aida-public/AB6AXuC2sy0Uv8lfkTLOFmFdUBw9v5Oojzbs2t3q_DnjTAK61Ih34e1R3oPie6wtuNUX2kKvM3o5r4_kh7APJ3mAoJHuE5b4w3_S8Fp2hevE4FoN8rPfJ8CjUhE-_I71ereHdcoE20ZD413I-wObOgNEhyG_oXlxEsQ32vvhHN1ybqFeMNOY-0NNuextdMvl-f4VqNTVhYtPIesjoSy6yy6xF6t7jNuNp2DhB74U-lFJC7oYmBdKzV82286tMggm9qHMxRYBflHAdfgirdM',
              'SCULPTED SILHOUETTES',
            ),
          ),
          const SizedBox(height: 32),
          _buildEditorialTextSection(),
        ],
      ),
    );
  }

  Widget _buildEditorialBanner(BuildContext context, String imageUrl, String title, String subtitle) {
    return SizedBox(
      height: 500,
      width: double.infinity,
      child: Stack(
        children: [
          Image.network(
            imageUrl,
            fit: BoxFit.cover,
            width: double.infinity,
            height: double.infinity,
          ),
          Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [Colors.transparent, Colors.black87],
              ),
            ),
          ),
          Positioned(
            bottom: 48,
            left: 24,
            right: 24,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: AppTypography.displayLg.copyWith(color: Colors.white),
                ),
                const SizedBox(height: 16),
                Text(
                  subtitle,
                  style: AppTypography.bodyLg.copyWith(color: Colors.white70),
                ),
                const SizedBox(height: 32),
                OutlinedButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => const ProductListingScreen(showBackButton: true),
                      ),
                    );
                  },
                  style: OutlinedButton.styleFrom(
                    foregroundColor: Colors.white,
                    side: const BorderSide(color: Colors.white),
                    padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 16),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
                  ),
                  child: Text('EXPLORE COLLECTION', style: AppTypography.labelSm.copyWith(letterSpacing: 2)),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildContainedBanner(String imageUrl, String title) {
    return Container(
      height: 300,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        image: DecorationImage(
          image: NetworkImage(imageUrl),
          fit: BoxFit.cover,
        ),
      ),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          gradient: const LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Colors.transparent, Colors.black54],
          ),
        ),
        alignment: Alignment.bottomLeft,
        padding: const EdgeInsets.all(24),
        child: Text(
          title,
          style: AppTypography.headlineH1.copyWith(color: Colors.white),
        ),
      ),
    );
  }

  Widget _buildEditorialTextSection() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('THE ART OF DRESSING', style: AppTypography.labelSm.copyWith(color: AppColors.secondary, letterSpacing: 2)),
          const SizedBox(height: 16),
          Text(
            'Discover the new structural aesthetics of modern luxury. A curated selection of high-end fashion journalism, blending raw intensity with a professional framework.',
            style: AppTypography.bodyLg.copyWith(color: AppColors.onSurfaceVariant),
          ),
        ],
      ),
    );
  }
}
