import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../theme/app_colors.dart';
import '../theme/app_typography.dart';
import '../services/auth_service.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  final _authService = AuthService();
  bool _isLoading = false;

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  Future<void> _handleLogin() async {
    final email = _emailController.text.trim();
    final password = _passwordController.text.trim();

    if (email.isEmpty || password.isEmpty) {
      _showError('Please enter both email and password.');
      return;
    }

    setState(() => _isLoading = true);

    try {
      await _authService.login(email: email, password: password);
      if (mounted) {
        Navigator.pushReplacementNamed(context, '/home');
      }
    } on FirebaseAuthException catch (e) {
      _showError(e.message ?? 'Login failed. Please try again.');
    } catch (e) {
      _showError('An unexpected error occurred.');
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  void _showError(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: AppColors.error,
        behavior: SnackBarBehavior.floating,
        margin: const EdgeInsets.all(16),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          children: [
            _buildHeroSection(context),
            _buildMarketingSection(),
          ],
        ),
      ),
    );
  }

  Widget _buildHeroSection(BuildContext context) {
    final screenHeight = MediaQuery.of(context).size.height;
    return SizedBox(
      height: screenHeight > 884 ? screenHeight : 884,
      child: Stack(
        children: [
          _buildBackgroundImage(),
          SafeArea(
            child: Column(
              children: [
                _buildHeader(),
                const Spacer(),
                _buildLoginCard(context),
                const SizedBox(height: 32),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBackgroundImage() {
    return Positioned.fill(
      child: Stack(
        children: [
          Image.network(
            'https://lh3.googleusercontent.com/aida-public/AB6AXuAv5m2Z5-i1QXugqaBdGpfZyxjMgCVYaCR8p6EZTuH-38lHgQEEaUlfFErz37F2ulE3R_tdQ83aMy24JMP8-2diLuLBDW7iNkGdfRIMSn-ZFdp0SxSnfp1MgkCklvfDQM5u1d0Q1pZZ-RCUNGDCcaIo76T-ylseZ6iFvly_iLKznWhHDmvxIEx2A0i5jUDVFbbyOQhaNDtaDoKloYeGCTZ3skt_K82nhePXnVkrqWSS5WcV1ytXkL1SSKcbaSaxzMyBOk94wus8oZY',
            fit: BoxFit.cover,
            width: double.infinity,
            height: double.infinity,
          ),
          Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Color.fromRGBO(0, 0, 0, 0.3),
                  Color.fromRGBO(0, 0, 0, 0.7),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return Padding(
      padding: const EdgeInsets.only(top: 48),
      child: Center(
        child: Text(
          'FASHION MART',
          style: AppTypography.headlineH1.copyWith(
            color: Colors.white,
            letterSpacing: 4,
            fontWeight: FontWeight.w900,
            shadows: [
              const Shadow(color: Colors.black26, offset: Offset(0, 2), blurRadius: 4),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildLoginCard(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 24),
      padding: const EdgeInsets.all(32),
      decoration: BoxDecoration(
        color: AppColors.surfaceContainerLowest,
        borderRadius: BorderRadius.circular(12),
        boxShadow: const [
          BoxShadow(
            color: Color.fromRGBO(4, 36, 25, 0.08),
            blurRadius: 32,
            offset: Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Text('Welcome Back', style: AppTypography.headlineH2.copyWith(color: AppColors.primary)),
          const SizedBox(height: 4),
          Text('Sign in to continue your curated experience.', style: AppTypography.bodyMd.copyWith(color: AppColors.outline, fontSize: 14)),
          const SizedBox(height: 32),
          _buildTextField('EMAIL ADDRESS', 'editorial@fashionmart.com', false, _emailController),
          const SizedBox(height: 16),
          _buildTextField('PASSWORD', '••••••••', true, _passwordController),
          const SizedBox(height: 32),
          ElevatedButton(
            onPressed: _isLoading ? null : _handleLogin,
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.primaryContainer,
              foregroundColor: AppColors.onPrimary,
              minimumSize: const Size(double.infinity, 48),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
            ),
            child: _isLoading
                ? const SizedBox(
                    height: 20,
                    width: 20,
                    child: CircularProgressIndicator(strokeWidth: 2, color: AppColors.onPrimary),
                  )
                : Text('LOGIN', style: AppTypography.labelSm.copyWith(letterSpacing: 2)),
          ),
          const SizedBox(height: 16),
          Center(
            child: TextButton(
              onPressed: () {},
              child: Text('Forgot Password?', style: AppTypography.labelSm.copyWith(color: AppColors.outline)),
            ),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(child: Container(height: 1, color: AppColors.surfaceContainerHigh)),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Text('OR', style: AppTypography.labelSm.copyWith(fontSize: 10, color: AppColors.outlineVariant)),
              ),
              Expanded(child: Container(height: 1, color: AppColors.surfaceContainerHigh)),
            ],
          ),
          const SizedBox(height: 24),
          OutlinedButton(
            onPressed: () {
              Navigator.pushNamed(context, '/signup');
            },
            style: OutlinedButton.styleFrom(
              foregroundColor: AppColors.primary,
              side: const BorderSide(color: AppColors.primary),
              minimumSize: const Size(double.infinity, 48),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
            ),
            child: Text('CREATE ACCOUNT', style: AppTypography.labelSm.copyWith(letterSpacing: 2)),
          ),
          const SizedBox(height: 24),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              _buildSocialButton(Icons.g_mobiledata), // Google
              const SizedBox(width: 24),
              _buildSocialButton(Icons.apple), // Apple
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildTextField(String label, String placeholder, bool isPassword, TextEditingController controller) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: AppTypography.labelSm.copyWith(color: AppColors.outline)),
        const SizedBox(height: 6),
        TextField(
          controller: controller,
          obscureText: isPassword,
          decoration: InputDecoration(
            hintText: placeholder,
            hintStyle: AppTypography.bodyMd.copyWith(color: AppColors.outlineVariant),
            filled: true,
            fillColor: AppColors.surfaceContainer,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: BorderSide.none),
            contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            suffixIcon: isPassword ? const Icon(Icons.visibility, color: AppColors.outline) : null,
          ),
        ),
      ],
    );
  }

  Widget _buildSocialButton(IconData icon) {
    return Container(
      width: 48,
      height: 48,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        border: Border.all(color: AppColors.surfaceContainerHigh),
      ),
      child: Icon(icon, color: AppColors.onSurface),
    );
  }

  Widget _buildMarketingSection() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 64),
      color: AppColors.background,
      child: Column(
        children: [
          Row(
            children: [
              Expanded(
                child: _buildMarketingCard(Icons.auto_awesome, 'Curated Selections', 'Exclusive pieces selected by world-class editorial teams, tailored to your aesthetic profile.'),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: _buildMarketingCard(Icons.local_shipping, 'White Glove Delivery', 'Experience the height of service with precision logistics and premium packaging.'),
              ),
            ],
          ),
          const SizedBox(height: 64),
          const Divider(color: AppColors.surfaceContainerHigh),
          const SizedBox(height: 32),
          Text('© 2024 Fashion Mart Editorial Group. All Rights Reserved.', style: AppTypography.labelSm.copyWith(fontSize: 10, color: AppColors.outlineVariant, letterSpacing: 2)),
        ],
      ),
    );
  }

  Widget _buildMarketingCard(IconData icon, String title, String description) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.surfaceContainerLow,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: AppColors.primary, size: 32),
          const SizedBox(height: 16),
          Text(title, style: AppTypography.headlineH2.copyWith(fontSize: 18, color: AppColors.primary)),
          const SizedBox(height: 8),
          Text(description, style: AppTypography.bodyMd.copyWith(color: AppColors.outline)),
        ],
      ),
    );
  }
}
