import 'package:flutter/material.dart';
import '../theme/app_colors.dart';
import '../theme/app_typography.dart';
import '../widgets/top_app_bar.dart';
import '../widgets/product_card.dart';
import 'product_listing_screen.dart';
import '../services/firestore_service.dart';
import '../models/product.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const CustomAppBar(),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildSearchSection(context),
            _buildHeroBanner(context),
            _buildCategories(context),
            _buildRecommendedSection(),
            _buildStayInspiredSection(),
          ],
        ),
      ),
    );
  }

  Widget _buildSearchSection(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
      child: GestureDetector(
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => const ProductListingScreen(showBackButton: true),
            ),
          );
        },
        child: Container(
          height: 48,
          decoration: BoxDecoration(
            color: AppColors.surfaceContainerLow,
            borderRadius: BorderRadius.circular(8),
          ),
          child: Row(
            children: [
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 16),
                child: Icon(Icons.search, color: AppColors.outline, size: 20),
              ),
              Expanded(
                child: AbsorbPointer(
                  child: TextField(
                    decoration: InputDecoration(
                      hintText: 'Search for styles...',
                      hintStyle: AppTypography.bodyMd.copyWith(color: AppColors.onSurfaceVariant),
                      border: InputBorder.none,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeroBanner(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24).copyWith(bottom: 32),
      child: Container(
        width: double.infinity,
        height: 400, // Roughly 4/5 aspect ratio depending on width
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          image: const DecorationImage(
            image: NetworkImage('https://lh3.googleusercontent.com/aida-public/AB6AXuAScFxavQ0p5G2kIZAhQp6jyuGqeYDmGaStI7vsf2oHA7pnrukob5nUteeOpVG251BHHdpiD7aTdmXBhT6xI5_jTNQNige7lmGzauocGHQuFYb0Cm9cPT4N9SpOKoHTf3e_u76ctnY0He6rNWQu3Ling8cQHFX-_GTClYqsT9kmfxpp9bZIPzefJYQtvE08-dWD_NBwPqJhhkHg1NLpXKb5pggo9pjFfY6pC9szp6qeWLZ9Rl3pghMOshCGCN5lBvOcjNWgpz0U7Uo'),
            fit: BoxFit.cover,
          ),
        ),
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12),
            gradient: LinearGradient(
              begin: Alignment.bottomCenter,
              end: Alignment.topCenter,
              colors: [
                Colors.black.withOpacity(0.4),
                Colors.transparent,
                Colors.transparent,
              ],
            ),
          ),
          padding: const EdgeInsets.all(32),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.end,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Summer Collection',
                style: AppTypography.displayLg.copyWith(color: Colors.white, fontSize: 32),
              ),
              const SizedBox(height: 16),
              ElevatedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const ProductListingScreen(showBackButton: true),
                    ),
                  );
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.onPrimary,
                  foregroundColor: AppColors.primary,
                  padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 12),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
                  elevation: 0,
                ),
                child: Text('SHOP NOW', style: AppTypography.labelSm),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildCategories(BuildContext context) {
    final categories = ['All', 'Tops', 'Dresses', 'Bags', 'Shoes', 'Jewelry'];
    return Padding(
      padding: const EdgeInsets.only(bottom: 32),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
            child: Text('Categories', style: AppTypography.headlineH2.copyWith(color: AppColors.primary)),
          ),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 24),
            child: Row(
              children: categories.map((cat) {
                final isSelected = cat == 'All';
                return Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: GestureDetector(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const ProductListingScreen(showBackButton: true),
                        ),
                      );
                    },
                    child: Container(
                       padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
                       decoration: BoxDecoration(
                         color: isSelected ? AppColors.primary : Colors.white,
                         borderRadius: BorderRadius.circular(24),
                         border: Border.all(
                           color: isSelected ? AppColors.primary : AppColors.surfaceVariant,
                         ),
                       ),
                       child: Text(
                         cat,
                         style: AppTypography.labelSm.copyWith(
                           color: isSelected ? AppColors.onPrimary : AppColors.primary,
                         ),
                       ),
                    ),
                  ),
                );
              }).toList(),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildRecommendedSection() {
    final firestoreService = FirestoreService();
    return StreamBuilder<List<Product>>(
      stream: firestoreService.getProductsStream(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Padding(
            padding: EdgeInsets.symmetric(vertical: 32),
            child: Center(child: CircularProgressIndicator(color: AppColors.primary)),
          );
        }
        final products = snapshot.data ?? [];
        final recommendedProducts = products.where((p) => p.id.startsWith('rec_')).toList();

        if (recommendedProducts.isEmpty) {
          return const SizedBox.shrink();
        }

        return Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24).copyWith(bottom: 64),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Recommended For You', style: AppTypography.headlineH2.copyWith(color: AppColors.primary)),
              const SizedBox(height: 16),
              GridView.count(
                crossAxisCount: 2,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                mainAxisSpacing: 16,
                crossAxisSpacing: 16,
                childAspectRatio: 0.6,
                children: recommendedProducts.map((product) {
                  return ProductCard(product: product);
                }).toList(),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildStayInspiredSection() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24).copyWith(bottom: 32),
      child: Container(
        width: double.infinity,
        height: 300,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          image: const DecorationImage(
            image: NetworkImage('https://lh3.googleusercontent.com/aida-public/AB6AXuA0anvni5AsKpTeOpOwELJf5LvhVPpRVs3Trd-_ROByhiFpoW1-o4RW8mqob-edK2Z52tsA9QNTjSY0XZIWMhaELYCLlATwUsKDbE0gB0OYTsx2hnvCix5prEJDwbFwiE4RqWqLxHPHJB83XvUsVH1W_m4286conbEeoCzgxkLmBfqDIY22i1Z_NffZWjGjnCkSge0tMe259uquhR-JVYeM7oBGxiiXSFt5gObxGQ4rb1yLpfMgI_op8aEaDnbZQyhp22w9YJjjhG4'),
            fit: BoxFit.cover,
          ),
        ),
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12),
            color: AppColors.primary.withOpacity(0.4),
          ),
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                'Stay Inspired',
                style: AppTypography.displayLg.copyWith(
                  color: Colors.white,
                  fontSize: 28,
                  fontStyle: FontStyle.italic,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'Discover the stories behind our latest curation and the artisans who create them.',
                style: AppTypography.bodyMd.copyWith(color: Colors.white.withOpacity(0.8), fontSize: 14),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 24),
              Container(
                decoration: const BoxDecoration(
                  border: Border(bottom: BorderSide(color: Colors.white, width: 1)),
                ),
                child: Text(
                  'READ JOURNAL',
                  style: AppTypography.labelSm.copyWith(color: Colors.white, letterSpacing: 2),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
