import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppTypography {
  static TextStyle get headlineH1 => GoogleFonts.notoSerif(
        fontSize: 32,
        height: 1.2,
        fontWeight: FontWeight.w600,
      );

  static TextStyle get headlineH2 => GoogleFonts.notoSerif(
        fontSize: 24,
        height: 1.3,
        fontWeight: FontWeight.w600,
      );

  static TextStyle get displayLg => GoogleFonts.notoSerif(
        fontSize: 40,
        height: 1.1,
        letterSpacing: -0.02 * 40,
        fontWeight: FontWeight.w700,
      );

  static TextStyle get bodyLg => GoogleFonts.manrope(
        fontSize: 18,
        height: 1.6,
        fontWeight: FontWeight.w400,
      );

  static TextStyle get bodyMd => GoogleFonts.manrope(
        fontSize: 16,
        height: 1.5,
        fontWeight: FontWeight.w400,
      );

  static TextStyle get labelSm => GoogleFonts.manrope(
        fontSize: 12,
        height: 1.2,
        letterSpacing: 0.05 * 12,
        fontWeight: FontWeight.w600,
      );
}
