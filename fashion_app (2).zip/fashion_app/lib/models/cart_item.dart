import 'package:flutter/material.dart';
import 'product.dart';

class CartItem {
  final Product product;
  final Color selectedColor;
  final String selectedSize;
  int quantity;

  CartItem({
    required this.product,
    required this.selectedColor,
    required this.selectedSize,
    this.quantity = 1,
  });

  double get totalPrice => product.price * quantity;

  String get formattedTotalPrice => '\$${totalPrice.toStringAsFixed(2)}';

  String get colorName {
    final colorVal = selectedColor.value;
    if (colorVal == const Color(0xFF1B3A2D).value) return "EMERALD";
    if (colorVal == const Color(0xFF18181B).value || colorVal == Colors.black.value || colorVal == Colors.grey.shade900.value) return "BLACK";
    if (colorVal == const Color(0xFFF2EDE5).value) return "OATMEAL";
    if (colorVal == const Color(0xFFC5B358).value) return "GOLD";
    if (colorVal == const Color(0xFF9E2A2B).value) return "BURGUNDY";
    if (colorVal == const Color(0xFF4A3B32).value) return "ESPRESSO";
    if (colorVal == const Color(0xFFA1A1AA).value || colorVal == Colors.grey.shade400.value) return "SILVER";
    if (colorVal == const Color(0xFF1C2D42).value) return "NAVY";
    if (colorVal == const Color(0xFF8B4513).value) return "TAN";
    if (colorVal == const Color(0xFF483D8B).value) return "INDIGO";
    if (colorVal == const Color(0xFFD2B48C).value) return "CAMEL";
    if (colorVal == const Color(0xFFF5F5DC).value) return "SAND";
    if (colorVal == const Color(0xFF808080).value) return "SLATE";
    if (colorVal == const Color(0xFFE5D3B3).value) return "BEIGE";
    return "CUSTOM";
  }

  String get specs => '$colorName / ${selectedSize.toUpperCase()}';
}
