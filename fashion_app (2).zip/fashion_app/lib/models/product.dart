import 'package:flutter/material.dart';

class Product {
  final String id;
  final String brand;
  final String name;
  final double price;
  final String imageUrl;
  final double rating;
  final int reviewCount;
  final String description;
  final List<Color> colors;
  final List<String> sizes;
  final List<String> lookIds; // Product IDs to "Complete the Look"

  const Product({
    required this.id,
    required this.brand,
    required this.name,
    required this.price,
    required this.imageUrl,
    required this.rating,
    required this.reviewCount,
    required this.description,
    required this.colors,
    required this.sizes,
    required this.lookIds,
  });

  String get formattedPrice => '\$${price.toStringAsFixed(2)}';
}
