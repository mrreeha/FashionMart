import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'firebase_options.dart';
import 'theme/app_colors.dart';
import 'theme/app_typography.dart';
import 'screens/checkout_screen.dart';
import 'screens/login_screen.dart';
import 'screens/signup_screen.dart';
import 'screens/editorial_screen.dart';
import 'screens/main_screen.dart';
import 'screens/order_history_screen.dart';
import 'services/data_migration.dart';
import 'services/firestore_service.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  try {
    print("Initializing Firebase...");
    await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
    print("Firebase initialized successfully.");
    await migrateProductsToFirestore();
  } catch (e, stackTrace) {
    print("Firebase/Migration Initialization error: $e");
    print(stackTrace);
  }
  runApp(const FashionApp());
}

class FashionApp extends StatelessWidget {
  const FashionApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Fashion Mart',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: AppColors.background,
        colorScheme: ColorScheme.fromSeed(
          seedColor: AppColors.primary,
          primary: AppColors.primary,
          secondary: AppColors.secondary,
          surface: AppColors.surface,
          background: AppColors.background,
          error: AppColors.error,
        ),
        textTheme: GoogleFonts.manropeTextTheme(Theme.of(context).textTheme)
            .copyWith(
              displayLarge: AppTypography.displayLg.copyWith(
                color: AppColors.onBackground,
              ),
              headlineLarge: AppTypography.headlineH1.copyWith(
                color: AppColors.primary,
              ),
              headlineMedium: AppTypography.headlineH2.copyWith(
                color: AppColors.primary,
              ),
              bodyLarge: AppTypography.bodyLg.copyWith(
                color: AppColors.onBackground,
              ),
              bodyMedium: AppTypography.bodyMd.copyWith(
                color: AppColors.onBackground,
              ),
              labelSmall: AppTypography.labelSm.copyWith(
                color: AppColors.onSurfaceVariant,
              ),
            ),
      ),
      home: const AuthGate(),
      routes: {
        '/home': (context) => const MainScreen(),
        '/login': (context) => const LoginScreen(),
        '/signup': (context) => const SignupScreen(),
        '/checkout': (context) => const CheckoutScreen(),
        '/editorial': (context) => const EditorialScreen(),
        '/order-history': (context) => const OrderHistoryScreen(),
      },
    );
  }
}

/// AuthGate listens to Firebase auth state and routes accordingly.
/// If user is logged in → MainScreen, otherwise → LoginScreen.
class AuthGate extends StatelessWidget {
  const AuthGate({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (context, snapshot) {
        // Show loading while checking auth state
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Scaffold(
            body: Center(
              child: CircularProgressIndicator(color: AppColors.primary),
            ),
          );
        }

        // User is logged in
        if (snapshot.hasData) {
          final user = snapshot.data!;
          FirestoreService().getUserDataStream(user.uid, user.email ?? '');
          return const MainScreen();
        }

        // User is not logged in
        return const LoginScreen();
      },
    );
  }
}
