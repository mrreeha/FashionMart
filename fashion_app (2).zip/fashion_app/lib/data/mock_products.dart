import 'package:flutter/material.dart';
import '../models/product.dart';

const List<Product> mockProducts = [
  // 1. Listing Screen Products
  Product(
    id: 'overcoat_01',
    brand: 'L\'ARTISAN',
    name: 'SCULPTED OVERCOAT',
    price: 450.00,
    imageUrl:
        'https://lh3.googleusercontent.com/aida-public/AB6AXuDCCb8zdVns8aKPY98Y-DaSnkTEr93TuSHDyXioK-5W_2CXjh12mIzigoZqdoaM642xW8uyJkVaHjUr0a5N6EthObG4M3_nS1rP7tGHskxRw_sCcplcvcBjvEuZMwbLXduoJa2OSIE6drlBRf2jjVi7TsDLErVU3L8f9w2A8wJa7ASCiN30A40DKsMO7Ylh5RYIox4MzIGwjvxp5h3Z91bfMKssrfejf-c1DhlsqvgPeaeQ0tRPNA8f7kEv_pZ2PVBoyuVJW7MIG8s',
    rating: 4.8,
    reviewCount: 42,
    description:
        'Crafted from a premium blend of virgin wool and cashmere, this sculpted overcoat features a dramatic silhouette that marries traditional tailoring with modern proportions. Detailed with hand-finished seams and sustainable horn buttons.',
    colors: [Color(0xFF1B3A2D), Color(0xFF18181B), Color(0xFFF2EDE5)],
    sizes: ['S', 'M', 'L', 'XL'],
    lookIds: ['scarf_01', 'boots_02', 'trousers_01'],
  ),
  Product(
    id: 'dress_01',
    brand: 'NOIR ÉDITION',
    name: 'SILK LAYER DRESS',
    price: 320.00,
    imageUrl:
        'https://lh3.googleusercontent.com/aida-public/AB6AXuDmwCJ0AYrtTVOHSM1Pjpt3774ifOyO3OR-XaoiKjijaSizivhH8ARwh6E0S0hX6QuuP7rY72eS0OhJtrI-aJjaxasxWVgq3ZfKxeC-J7UTu9o0V1q9ih7S_RI7PzOn7i_j62kNXXVuITUzOEJ6hZaE7f9NxHWOTcBugalSd7rQ0BX0nUsS-xeoZX6RtRy7sZKGEjeLgfzsVtj7fvlwquuPS4i3NGxL8qSKbZXyEPQj3hqiGoKX1-uxLokQgSPY90YLRvav8o8SFrU',
    rating: 4.7,
    reviewCount: 29,
    description:
        'A fluid silhouette crafted from lightweight organic silk. Features delicate layering, an elegant wrap front, and an adjustable waist tie for a bespoke fit.',
    colors: [Color(0xFF18181B), Color(0xFFC5B358), Color(0xFF9E2A2B)],
    sizes: ['XS', 'S', 'M', 'L'],
    lookIds: ['scarf_01', 'boots_02'],
  ),
  Product(
    id: 'boots_01',
    brand: 'STUDIO BASICS',
    name: 'CHELSEA LEATHER BOOT',
    price: 285.00,
    imageUrl:
        'https://lh3.googleusercontent.com/aida-public/AB6AXuBBLdXk5cBZF_b3Zu3s_p3P7Ts7aYFuXa0k6aFbSamJLQAD2PW48ak5Q4ZbUlSgwPSWWu2OzHc582uAoYSkWFarBcrIS8Qp5kaOfoQBeBM_1_EH3T8h9YQZnR9AyKTAcP_RiIyjbLjcYv05prVSi0acBkZOR7UtH0tvU8KHwaoNyNH8yoLqzyJkR3pJ_bkJoM_sPMkwDp-kCniQ5pG9Sfm2bJFqlKO8GA5P2FIFxKRYK5Pn34OCsxTwK6UyLn_p2zizsm2zDsG8k4k',
    rating: 4.9,
    reviewCount: 56,
    description:
        'Handcrafted in Italy using supple full-grain calfskin leather. Featuring durable elastic side panels, a pull tab, and a stacked leather heel. A modern wardrobe essential.',
    colors: [Color(0xFF4A3B32), Color(0xFF18181B)],
    sizes: ['7', '8', '9', '10', '11'],
    lookIds: ['trousers_01'],
  ),
  Product(
    id: 'blazer_01',
    brand: 'ESSENTIALS',
    name: 'TAILORED BLAZER',
    price: 195.00,
    imageUrl:
        'https://lh3.googleusercontent.com/aida-public/AB6AXuCrQckjnY5a4K0R77OWP3ZuJw4fat38xWz8qyjPfZgGbN4Dfg7tCmtlTqeIJDfUO-EvCuldqSiNfRVU_faJv3dY59AmX1mPx59i5MAok6Gy7GEYITKaH30gqXm9PAp4EYWxTlJppdWWsgeTMSMcX-xMneYPZmFrYdoWhFgGkPg6U4vozJAUUgDrIn2jvOPF9dmFMtXoHqBcjxB3uA-RPfkCgIBNAFcsF5hO7MJCOMbWM23nbkwMzPzf79TkvFMEp0pltGhIz8TwMfY',
    rating: 4.6,
    reviewCount: 34,
    description:
        'A sharp, structured blazer designed for a relaxed yet polished fit. Features notched lapels, single-breasted horn button closure, and functional flap pockets.',
    colors: [Color(0xFFA1A1AA), Color(0xFF18181B), Color(0xFF1C2D42)],
    sizes: ['S', 'M', 'L'],
    lookIds: ['trousers_01', 'boots_02'],
  ),

  // 2. HomeScreen Recommended Products
  Product(
    id: 'rec_dress_01',
    brand: 'NOIR ÉDITION',
    name: 'Silk Wrap Midi Dress',
    price: 295.00,
    imageUrl:
        'https://lh3.googleusercontent.com/aida-public/AB6AXuB-mfntiXwL122QTgetEOd_VL8fA2EbsYhlqWKEF-TSn193NTxogn2lw9g7Zr6S2LEzsUB0nSJ-pORr3AH5YktZlgt4W0HPphY-eNR23380T5DC2-Ea1CMinWNx0Z39rH1AmqWNOfDI4BAqQRh6g46Vr9khLv3836zURfdrmxxa1cyZz7X7ml61KCve6wp19UlbJv3F55i5fuC4M9DOjruUZySjXAARt8b_iJ8lkn_CPQLSasBtqQCKmT9liXiRKMuYogPKi6l9VTg',
    rating: 4.7,
    reviewCount: 31,
    description:
        'Exquisitely tailored silk wrap dress featuring a deep V-neckline, asymmetrical midi hem, and a luxurious drape. Designed to gracefully elevate day-to-evening dressing.',
    colors: [Color(0xFF8B4513), Color(0xFF18181B), Color(0xFF483D8B)],
    sizes: ['XS', 'S', 'M', 'L'],
    lookIds: ['scarf_01', 'boots_02'],
  ),
  Product(
    id: 'rec_tote_01',
    brand: 'STUDIO BASICS',
    name: 'Classic Leather Tote',
    price: 450.00,
    imageUrl:
        'https://lh3.googleusercontent.com/aida-public/AB6AXuCU_U88rsmX_eFTFx-kCqMD1IFW5TnvHRoEqWf0gvSfdqNOPy3BUw7Pb1hyWbEzysgEdfQgDn-M_fTltSF04Kzr59Lg_Xlsqx4LFNGroW6AMbmhLn1j_5nclVDGBM73BV7p9X9ezO1YVZl8p6ofPHRLXhzTfVY43ccFVnBl1mx-ldmi8oJSzx2VyxaVMED0R8ut_oDdGECxepFHK4aLpxx66crC1jvU53OZ2Oy-yK0-r-ir98QGOz4evmdbpEtW1p-cQBLyBqQdWhI',
    rating: 4.8,
    reviewCount: 48,
    description:
        'Made from premium double-faced pebbled leather, this structured tote offers generous space, clean minimalist lines, an internal zip pocket, and comfortable shoulder straps.',
    colors: [Color(0xFFD2B48C), Color(0xFF18181B)],
    sizes: ['One Size'],
    lookIds: ['scarf_01'],
  ),
  Product(
    id: 'rec_blazer_01',
    brand: 'ESSENTIALS',
    name: 'Linen Blend Blazer',
    price: 180.00,
    imageUrl:
        'https://lh3.googleusercontent.com/aida-public/AB6AXuCnaWwAQWVZivvo5YKL9pQYFVyTB8HT_TRg54vQBFBOwweCYrLu0a9Xa1zdo_g5Hq5FUCseSgTWLtdEYsGMDxh2FcTWhXhyeeLy18LD7m1Z42fE8wbeCaovG2y-ewFJo-yTWNm7--I7t6V9-viBv58FFbhnX_bzGaScwXopc7OquJCgF6cp4UJirF3-tocZ_0AGPoG_uNM5I6S5JzfDyBZkd_j9Ee7AsMplhRKNJbghdrn6HDxAElGrlQlwiyWO8XXXZiZ07j7cOUA',
    rating: 4.5,
    reviewCount: 19,
    description:
        'Lightweight and breathable, this linen-blend blazer is perfect for warm weather layering. Unlined construction with structural shoulders and functional patch pockets.',
    colors: [Color(0xFFF5F5DC), Color(0xFF808080)],
    sizes: ['S', 'M', 'L', 'XL'],
    lookIds: ['trousers_01', 'boots_02'],
  ),
  Product(
    id: 'rec_slide_01',
    brand: 'STUDIO BASICS',
    name: 'Minimalist Slide',
    price: 120.00,
    imageUrl:
        'https://lh3.googleusercontent.com/aida-public/AB6AXuCpuXnFf6aBpbkpNp7DgVi2_M2TWuD0ZQImiBGqACyLQpPi_NMV-ODv4QxuBpw217SFLBad38GMbI7JchK-w214PlPYb_fMKuGunJ6J9S4yXp91v0JZPqLKumSZFi7_1H1DIOHaIM9wHXBX_top1msAN5N3ocEFuN5JbdqSqJ3fFdxo974m8LuhMX5jThJSjCLRovRAK0kD-mdDEKlTDPIhyGGU9-aYUxr99RaWHtRak1lRTVBwo_Xg0Gqs7dYd9tXpGhum-y4uRj0',
    rating: 4.4,
    reviewCount: 22,
    description:
        'Crafted in buttery soft leather, these minimalist slip-on slides feature a padded footbed for all-day comfort and a streamlined strap design that complements any summer look.',
    colors: [Color(0xFFE5D3B3), Color(0xFF18181B)],
    sizes: ['6', '7', '8', '9', '10'],
    lookIds: ['scarf_01'],
  ),

  // 3. Look Items (Complete the Look)
  Product(
    id: 'scarf_01',
    brand: 'ESSENTIALS',
    name: 'Cashmere Scarf',
    price: 85.00,
    imageUrl:
        'https://lh3.googleusercontent.com/aida-public/AB6AXuBA20ub2M8S0fmlgJ5Vyn86E66gDw4tIT6KNpnifTzWMb61rAQ7wneDwvdqN8Bj-VTLfdjhdD2ohS9jvAGS5cnBiu2H7XLhEDR2W_SRyt0NQp9jl0F7Y-DzhYwB5ClOtLjIY8_7yhrnw1Fstk9w_qMMIq_SPNGfObVgnW249d0n-8k0VDuDBokYtu5aWsL6XNVtRdqr7T-ASqe1V1Tgm_eiEvKarjBt0pGfZi5beYucRzVU8WKS3JP2y_pHXewhV1PsxsBSmeMKI7k',
    rating: 4.9,
    reviewCount: 65,
    description:
        'Wrap yourself in absolute luxury. Woven from Grade-A Mongolian cashmere, this scarf features exceptionally soft hand-feel and light fringe detail.',
    colors: [Color(0xFFF2EDE5), Color(0xFF18181B), Color(0xFF8B4513)],
    sizes: ['One Size'],
    lookIds: ['overcoat_01'],
  ),
  Product(
    id: 'boots_02',
    brand: 'STUDIO BASICS',
    name: 'Chelsea Boots',
    price: 210.00,
    imageUrl:
        'https://lh3.googleusercontent.com/aida-public/AB6AXuDy7ueZHvelzrON9Ai8C1LwW3r3zwvvRutkw3GtsOdcCtIVoW2Gn_NlOwljnrjN9HU2xrZlFbREz7pyg5BUY-KZECeUFwefcYAsPpwZwV9-Q3_rAbDugYoC6zR1mo1vaRYLQSi_rfFUxOHDin41qFpA7nsmDRnA-j7Bvj3GAq2n_960kicv6Hs9mj4fbWPQj5wqVI2J-NTaDcW2FngG8uJHwz_xUyQvMK3_bV_sgRwCvnsFh8Fkam59MOUTBiybI46EQaMAL2hYS5g',
    rating: 4.8,
    reviewCount: 78,
    description:
        'Sleek, streamlined ankle boots crafted from water-resistant split suede. Detailed with tonal elastic side panels and durable crepe soles.',
    colors: [Color(0xFF8B4513), Color(0xFF18181B)],
    sizes: ['7', '8', '9', '10', '11'],
    lookIds: ['trousers_01'],
  ),
  Product(
    id: 'trousers_01',
    brand: 'L\'ARTISAN',
    name: 'Tailored Trousers',
    price: 145.50,
    imageUrl:
        'https://lh3.googleusercontent.com/aida-public/AB6AXuCEc6ldfzRFgxOSWEEj61bl8DvCWpA9uNOCVSt1EU3rwxYuuLUL8941P1oGnpDbWw_aT0EtCyBHWdXWDiDIaF0P7qYRaYgGq_rB8FNGu7bPZXUUcVCISxZlrcVaaFFJTA9kmQq603vWkuMxZosDlF4SWTKMUCm70SmP0oO3kcfKROgkGRIJ7Kv_LpJLbN_CC9gxGobwtHsXI7VYFeNzzDxn4Qbv1Hlc_91vxWi9nfAT6F4vaNJ_vLuWKL7ECPxy0AoxS2S7MbCWv4U',
    rating: 4.7,
    reviewCount: 40,
    description:
        'A classic flat-front dress pant crafted in a mid-weight wool blend. Tailored with a clean straight-leg cut, belt loops, and side slip pockets.',
    colors: [Color(0xFF18181B), Color(0xFF808080)],
    sizes: ['28', '30', '32', '34'],
    lookIds: ['blazer_01', 'boots_01'],
  ),
];

Product getProductById(String id) {
  return mockProducts.firstWhere(
    (product) => product.id == id,
    orElse: () => mockProducts.first,
  );
}
