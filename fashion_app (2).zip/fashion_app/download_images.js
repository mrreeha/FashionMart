const fs = require('fs');
const path = require('path');
const https = require('https');

const dir = path.join(__dirname, 'assets', 'images');
if (!fs.existsSync(dir)) {
  fs.mkdirSync(dir, { recursive: true });
}

const images = {
  'login_bg.jpg': 'https://lh3.googleusercontent.com/aida-public/AB6AXuAv5m2Z5-i1QXugqaBdGpfZyxjMgCVYaCR8p6EZTuH-38lHgQEEaUlfFErz37F2ulE3R_tdQ83aMy24JMP8-2diLuLBDW7iNkGdfRIMSn-ZFdp0SxSnfp1MgkCklvfDQM5u1d0Q1pZZ-RCUNGDCcaIo76T-ylseZ6iFvly_iLKznWhHDmvxIEx2A0i5jUDVFbbyOQhaNDtaDoKloYeGCTZ3skt_K82nhePXnVkrqWSS5WcV1ytXkL1SSKcbaSaxzMyBOk94wus8oZY',
  'profile_avatar.jpg': 'https://lh3.googleusercontent.com/aida-public/AB6AXuASjSO1qV8YQLlHAgdvCcBvK4Yx_BQYMlYwwQEAKG53umDOPjMiSs9fR7t6QQ6pJL_glG8K_n925TAV6D37FXTfpcHtDSIFgQQ86t-kwcAX46zj-bB9Kg1q0-WH8vEjFxqe1omtlv1BvSHDfK0HUUGX9Q63k2vyfhTWwSW015yYITGcdZTTKQs-y5x-cwUcYiUrofxbDvWGcezLWo3ocm4IUphryByqPVSrnNbBVk9xzT1h7-j2FH5NmQxX5RvvI2EsBndpD3AuLbc',
  'home_banner.jpg': 'https://lh3.googleusercontent.com/aida-public/AB6AXuAScFxavQ0p5G2kIZAhQp6jyuGqeYDmGaStI7vsf2oHA7pnrukob5nUteeOpVG251BHHdpiD7aTdmXBhT6xI5_jTNQNige7lmGzauocGHQuFYb0Cm9cPT4N9SpOKoHTf3e_u76ctnY0He6rNWQu3Ling8cQHFX-_GTClYqsT9kmfxpp9bZIPzefJYQtvE08-dWD_NBwPqJhhkHg1NLpXKb5pggo9pjFfY6pC9szp6qeWLZ9Rl3pghMOshCGCN5lBvOcjNWgpz0U7Uo',
  'home_collection.jpg': 'https://lh3.googleusercontent.com/aida-public/AB6AXuA0anvni5AsKpTeOpOwELJf5LvhVPpRVs3Trd-_ROByhiFpoW1-o4RW8mqob-edK2Z52tsA9QNTjSY0XZIWMhaELYCLlATwUsKDbE0gB0OYTsx2hnvCix5prEJDwbFwiE4RqWqLxHPHJB83XvUsVH1W_m4286conbEeoCzgxkLmBfqDIY22i1Z_NffZWjGjnCkSge0tMe259uquhR-JVYeM7oBGxiiXSFt5gObxGQ4rb1yLpfMgI_op8aEaDnbZQyhp22w9YJjjhG4',
  'editorial_sculpted.jpg': 'https://lh3.googleusercontent.com/aida-public/AB6AXuC2sy0Uv8lfkTLOFmFdUBw9v5Oojzbs2t3q_DnjTAK61Ih34e1R3oPie6wtuNUX2kKvM3o5r4_kh7APJ3mAoJHuE5b4w3_S8Fp2hevE4FoN8rPfJ8CjUhE-_I71ereHdcoE20ZD413I-wObOgNEhyG_oXlxEsQ32vvhHN1ybqFeMNOY-0NNuextdMvl-f4VqNTVhYtPIesjoSy6yy6xF6t7jNuNp2DhB74U-lFJC7oYmBdKzV82286tMggm9qHMxRYBflHAdfgirdM',
  'overcoat_01.jpg': 'https://lh3.googleusercontent.com/aida-public/AB6AXuDCCb8zdVns8aKPY98Y-DaSnkTEr93TuSHDyXioK-5W_2CXjh12mIzigoZqdoaM642xW8uyJkVaHjUr0a5N6EthObG4M3_nS1rP7tGHskxRw_sCcplcvcBjvEuZMwbLXduoJa2OSIE6drlBRf2jjVi7TsDLErVU3L8f9w2A8wJa7ASCiN30A40DKsMO7Ylh5RYIox4MzIGwjvxp5h3Z91bfMKssrfejf-c1DhlsqvgPeaeQ0tRPNA8f7kEv_pZ2PVBoyuVJW7MIG8s',
  'dress_01.jpg': 'https://lh3.googleusercontent.com/aida-public/AB6AXuDmwCJ0AYrtTVOHSM1Pjpt3774ifOyO3OR-XaoiKjijaSizivhH8ARwh6E0S0hX6QuuP7rY72eS0OhJtrI-aJjaxasxWVgq3ZfKxeC-J7UTu9o0V1q9ih7S_RI7PzOn7i_j62kNXXVuITUzOEJ6hZaE7f9NxHWOTcBugalSd7rQ0BX0nUsS-xeoZX6RtRy7sZKGEjeLgfzsVtj7fvlwquuPS4i3NGxL8qSKbZXyEPQj3hqiGoKX1-uxLokQgSPY90YLRvav8o8SFrU',
  'boots_01.jpg': 'https://lh3.googleusercontent.com/aida-public/AB6AXuBBLdXk5cBZF_b3Zu3s_p3P7Ts7aYFuXa0k6aFbSamJLQAD2PW48ak5Q4ZbUlSgwPSWWu2OzHc582uAoYSkWFarBcrIS8Qp5kaOfoQBeBM_1_EH3T8h9YQZnR9AyKTAcP_RiIyjbLjcYv05prVSi0acBkZOR7UtH0tvU8KHwaoNyNH8yoLqzyJkR3pJ_bkJoM_sPMkwDp-kCniQ5pG9Sfm2bJFqlKO8GA5P2FIFxKRYK5Pn34OCsxTwK6UyLn_p2zizsm2zDsG8k4k',
  'blazer_01.jpg': 'https://lh3.googleusercontent.com/aida-public/AB6AXuCrQckjnY5a4K0R77OWP3ZuJw4fat38xWz8qyjPfZgGbN4Dfg7tCmtlTqeIJDfUO-EvCuldqSiNfRVU_faJv3dY59AmX1mPx59i5MAok6Gy7GEYITKaH30gqXm9PAp4EYWxTlJppdWWsgeTMSMcX-xMneYPZmFrYdoWhFgGkPg6U4vozJAUUgDrIn2jvOPF9dmFMtXoHqBcjxB3uA-RPfkCgIBNAFcsF5hO7MJCOMbWM23nbkwMzPzf79TkvFMEp0pltGhIz8TwMfY',
  'rec_dress_01.jpg': 'https://lh3.googleusercontent.com/aida-public/AB6AXuB-mfntiXwL122QTgetEOd_VL8fA2EbsYhlqWKEF-TSn193NTxogn2lw9g7Zr6S2LEzsUB0nSJ-pORr3AH5YktZlgt4W0HPphY-eNR23380T5DC2-Ea1CMinWNx0Z39rH1AmqWNOfDI4BAqQRh6g46Vr9khLv3836zURfdrmxxa1cyZz7X7ml61KCve6wp19UlbJv3F55i5fuC4M9DOjruUZySjXAARt8b_iJ8lkn_CPQLSasBtqQCKmT9liXiRKMuYogPKi6l9VTg',
  'rec_tote_01.jpg': 'https://lh3.googleusercontent.com/aida-public/AB6AXuCU_U88rsmX_eFTFx-kCqMD1IFW5TnvHRoEqWf0gvSfdqNOPy3BUw7Pb1hyWbEzysgEdfQgDn-M_fTltSF04Kzr59Lg_Xlsqx4LFNGroW6AMbmhLn1j_5nclVDGBM73BV7p9X9ezO1YVZl8p6ofPHRLXhzTfVY43ccFVnBl1mx-ldmi8oJSzx2VyxaVMED0R8ut_oDdGECxepFHK4aLpxx66crC1jvU53OZ2Oy-yK0-r-ir98QGOz4evmdbpEtW1p-cQBLyBqQdWhI',
  'rec_blazer_01.jpg': 'https://lh3.googleusercontent.com/aida-public/AB6AXuCnaWwAQWVZivvo5YKL9pQYFVyTB8HT_TRg54vQBFBOwweCYrLu0a9Xa1zdo_g5Hq5FUCseSgTWLtdEYsGMDxh2FcTWhXhyeeLy18LD7m1Z42fE8wbeCaovG2y-ewFJo-yTWNm7--I7t6V9-viBv58FFbhnX_bzGaScwXopc7OquJCgF6cp4UJirF3-tocZ_0AGPoG_uNM5I6S5JzfDyBZkd_j9Ee7AsMplhRKNJbghdrn6HDxAElGrlQlwiyWO8XXXZiZ07j7cOUA',
  'rec_slide_01.jpg': 'https://lh3.googleusercontent.com/aida-public/AB6AXuCpuXnFf6aBpbkpNp7DgVi2_M2TWuD0ZQImiBGqACyLQpPi_NMV-ODv4QxuBpw217SFLBad38GMbI7JchK-w214PlPYb_fMKuGunJ6J9S4yXp91v0JZPqLKumSZFi7_1H1DIOHaIM9wHXBX_top1msAN5N3ocEFuN5JbdqSqJ3fFdxo974m8LuhMX5jThJSjCLRovRAK0kD-mdDEKlTDPIhyGGU9-aYUxr99RaWHtRak1lRTVBwo_Xg0Gqs7dYd9tXpGhum-y4uRj0',
  'scarf_01.jpg': 'https://lh3.googleusercontent.com/aida-public/AB6AXuBA20ub2M8S0fmlgJ5Vyn86E66gDw4tIT6KNpnifTzWMb61rAQ7wneDwvdqN8Bj-VTLfdjhdD2ohS9jvAGS5cnBiu2H7XLhEDR2W_SRyt0NQp9jl0F7Y-DzhYwB5ClOtLjIY8_7yhrnw1Fstk9w_qMMIq_SPNGfObVgnW249d0n-8k0VDuDBokYtu5aWsL6XNVtRdqr7T-ASqe1V1Tgm_eiEvKarjBt0pGfZi5beYucRzVU8WKS3JP2y_pHXewhV1PsxsBSmeMKI7k',
  'boots_02.jpg': 'https://lh3.googleusercontent.com/aida-public/AB6AXuDy7ueZHvelzrON9Ai8C1LwW3r3zwvvRutkw3GtsOdcCtIVoW2Gn_NlOwljnrjN9HU2xrZlFbREz7pyg5BUY-KZECeUFwefcYAsPpwZwV9-Q3_rAbDugYoC6zR1mo1vaRYLQSi_rfFUxOHDin41qFpA7nsmDRnA-j7Bvj3GAq2n_960kicv6Hs9mj4fbWPQj5wqVI2J-NTaDcW2FngG8uJHwz_xUyQvMK3_bV_sgRwCvnsFh8Fkam59MOUTBiybI46EQaMAL2hYS5g',
  'trousers_01.jpg': 'https://lh3.googleusercontent.com/aida-public/AB6AXuCEc6ldfzRFgxOSWEEj61bl8DvCWpA9uNOCVSt1EU3rwxYuuLUL8941P1oGnpDbWw_aT0EtCyBHWdXWDiDIaF0P7qYRaYgGq_rB8FNGu7bPZXUUcVCISxZlrcVaaFFJTA9kmQq603vWkuMxZosDlF4SWTKMUCm70SmP0oO3kcfKROgkGRIJ7Kv_LpJLbN_CC9gxGobwtHsXI7VYFeNzzDxn4Qbv1Hlc_91vxWi9nfAT6F4vaNJ_vLuWKL7ECPxy0AoxS2S7MbCWv4U'
};

const download = (filename, url) => {
  return new Promise((resolve, reject) => {
    const file = fs.createWriteStream(path.join(dir, filename));
    https.get(url, (response) => {
      response.pipe(file);
      file.on('finish', () => {
        file.close();
        console.log(`Downloaded ${filename}`);
        resolve();
      });
    }).on('error', (err) => {
      fs.unlink(path.join(dir, filename), () => {});
      console.error(`Error downloading ${filename}:`, err);
      reject(err);
    });
  });
};

async function downloadAll() {
  for (const [filename, url] of Object.entries(images)) {
    try {
      await download(filename, url);
    } catch (e) {
      console.error(e);
    }
  }
  console.log("All downloads complete!");
}

downloadAll();
